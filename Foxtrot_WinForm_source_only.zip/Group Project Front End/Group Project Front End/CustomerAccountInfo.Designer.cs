﻿namespace Group_Project_Front_End
{
    partial class CustomerAccountInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtSelect = new Label();
            pnlFnctScrn = new Panel();
            btnBack = new Button();
            lblHogBank = new Label();
            pictureBox1 = new PictureBox();
            lblCustomerName = new Label();
            lblSQLCustomerName = new Label();
            lblCustomerData = new Label();
            dgvAccounts = new DataGridView();
            dgvCustomerDetails = new DataGridView();
            pnlFnctScrn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvAccounts).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvCustomerDetails).BeginInit();
            SuspendLayout();
            // 
            // txtSelect
            // 
            txtSelect.AutoSize = true;
            txtSelect.FlatStyle = FlatStyle.Flat;
            txtSelect.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtSelect.Location = new Point(155, 547);
            txtSelect.Margin = new Padding(7, 0, 7, 0);
            txtSelect.Name = "txtSelect";
            txtSelect.Size = new Size(807, 116);
            txtSelect.TabIndex = 21;
            txtSelect.Text = "Select an Account:";
            // 
            // pnlFnctScrn
            // 
            pnlFnctScrn.BackColor = Color.FromArgb(64, 64, 64);
            pnlFnctScrn.Controls.Add(btnBack);
            pnlFnctScrn.Controls.Add(lblHogBank);
            pnlFnctScrn.Controls.Add(pictureBox1);
            pnlFnctScrn.Dock = DockStyle.Top;
            pnlFnctScrn.Location = new Point(0, 0);
            pnlFnctScrn.Margin = new Padding(7, 8, 7, 8);
            pnlFnctScrn.Name = "pnlFnctScrn";
            pnlFnctScrn.Size = new Size(3468, 306);
            pnlFnctScrn.TabIndex = 22;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.Transparent;
            btnBack.BackgroundImage = Properties.Resources.BackArrow;
            btnBack.BackgroundImageLayout = ImageLayout.Zoom;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.ForeColor = Color.Transparent;
            btnBack.Location = new Point(3225, 22);
            btnBack.Margin = new Padding(7, 8, 7, 8);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(233, 262);
            btnBack.TabIndex = 106;
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // lblHogBank
            // 
            lblHogBank.AutoSize = true;
            lblHogBank.Font = new Font("Segoe UI", 39F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHogBank.ForeColor = Color.Transparent;
            lblHogBank.Location = new Point(583, 44);
            lblHogBank.Margin = new Padding(7, 0, 7, 0);
            lblHogBank.Name = "lblHogBank";
            lblHogBank.Size = new Size(2604, 173);
            lblHogBank.TabIndex = 1;
            lblHogBank.Text = "HOG BANK - CUSTOMER/ACCOUNT INFO";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.RazorBack1;
            pictureBox1.Location = new Point(19, 22);
            pictureBox1.Margin = new Padding(7, 8, 7, 8);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(525, 262);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // lblCustomerName
            // 
            lblCustomerName.AutoSize = true;
            lblCustomerName.FlatStyle = FlatStyle.Flat;
            lblCustomerName.Font = new Font("Segoe UI", 26.25F);
            lblCustomerName.Location = new Point(97, 394);
            lblCustomerName.Margin = new Padding(7, 0, 7, 0);
            lblCustomerName.Name = "lblCustomerName";
            lblCustomerName.Size = new Size(718, 116);
            lblCustomerName.TabIndex = 23;
            lblCustomerName.Text = "Viewing Data for:";
            // 
            // lblSQLCustomerName
            // 
            lblSQLCustomerName.AutoSize = true;
            lblSQLCustomerName.FlatStyle = FlatStyle.Flat;
            lblSQLCustomerName.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSQLCustomerName.ForeColor = Color.FromArgb(192, 0, 0);
            lblSQLCustomerName.Location = new Point(816, 392);
            lblSQLCustomerName.Margin = new Padding(7, 0, 7, 0);
            lblSQLCustomerName.Name = "lblSQLCustomerName";
            lblSQLCustomerName.Size = new Size(940, 116);
            lblSQLCustomerName.TabIndex = 24;
            lblSQLCustomerName.Text = "Customer Name Here";
            // 
            // lblCustomerData
            // 
            lblCustomerData.AutoSize = true;
            lblCustomerData.FlatStyle = FlatStyle.Flat;
            lblCustomerData.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCustomerData.Location = new Point(1457, 547);
            lblCustomerData.Margin = new Padding(7, 0, 7, 0);
            lblCustomerData.Name = "lblCustomerData";
            lblCustomerData.Size = new Size(665, 116);
            lblCustomerData.TabIndex = 25;
            lblCustomerData.Text = "Customer Info:";
            // 
            // dgvAccounts
            // 
            dgvAccounts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAccounts.Location = new Point(194, 722);
            dgvAccounts.Margin = new Padding(7, 8, 7, 8);
            dgvAccounts.Name = "dgvAccounts";
            dgvAccounts.RowHeadersWidth = 102;
            dgvAccounts.Size = new Size(1107, 1246);
            dgvAccounts.TabIndex = 26;
            dgvAccounts.CellClick += dgvAccounts_CellClick;
            // 
            // dgvCustomerDetails
            // 
            dgvCustomerDetails.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCustomerDetails.Location = new Point(1477, 722);
            dgvCustomerDetails.Margin = new Padding(7, 8, 7, 8);
            dgvCustomerDetails.Name = "dgvCustomerDetails";
            dgvCustomerDetails.RowHeadersWidth = 102;
            dgvCustomerDetails.Size = new Size(1826, 1246);
            dgvCustomerDetails.TabIndex = 27;
            // 
            // CustomerAccountInfo
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(3468, 2048);
            Controls.Add(dgvCustomerDetails);
            Controls.Add(dgvAccounts);
            Controls.Add(lblCustomerData);
            Controls.Add(lblSQLCustomerName);
            Controls.Add(lblCustomerName);
            Controls.Add(pnlFnctScrn);
            Controls.Add(txtSelect);
            Margin = new Padding(7, 8, 7, 8);
            MaximizeBox = false;
            Name = "CustomerAccountInfo";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CustomerAccountInfo";
            Load += CustomerAccountInfo_Load;
            pnlFnctScrn.ResumeLayout(false);
            pnlFnctScrn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvAccounts).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvCustomerDetails).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label txtSelect;
        private Panel pnlFnctScrn;
        private Label lblHogBank;
        private PictureBox pictureBox1;
        private Label lblCustomerName;
        private Label lblSQLCustomerName;
        private Label lblCustomerData;
        private DataGridView dgvAccounts;
        private DataGridView dgvCustomerDetails;
        private Button btnBack;
    }
}