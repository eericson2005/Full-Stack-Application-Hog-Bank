﻿namespace Group_Project_Front_End
{
    partial class Main_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtEmail = new TextBox();
            btnLogin = new Button();
            pictureBox1 = new PictureBox();
            lblUserIcon = new PictureBox();
            lblPassIcon = new PictureBox();
            txtPassword = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)lblUserIcon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)lblPassIcon).BeginInit();
            SuspendLayout();
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtEmail.Location = new Point(583, 944);
            txtEmail.Margin = new Padding(0, 3, 2, 3);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(694, 87);
            txtEmail.TabIndex = 0;
            txtEmail.KeyDown += txtEmployeeID_KeyDown;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.FromArgb(159, 40, 24);
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLogin.ForeColor = Color.White;
            btnLogin.Location = new Point(622, 1356);
            btnLogin.Margin = new Padding(2, 3, 2, 3);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(525, 153);
            btnLogin.TabIndex = 8;
            btnLogin.Text = "Sign In";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.UserIcon;
            pictureBox1.Location = new Point(753, 194);
            pictureBox1.Margin = new Padding(2, 3, 2, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(0, 0);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // lblUserIcon
            // 
            lblUserIcon.Image = Properties.Resources.UserIcon1;
            lblUserIcon.Location = new Point(486, 940);
            lblUserIcon.Margin = new Padding(7, 8, 0, 8);
            lblUserIcon.Name = "lblUserIcon";
            lblUserIcon.Size = new Size(95, 95);
            lblUserIcon.SizeMode = PictureBoxSizeMode.Zoom;
            lblUserIcon.TabIndex = 6;
            lblUserIcon.TabStop = false;
            // 
            // lblPassIcon
            // 
            lblPassIcon.Image = Properties.Resources.Password_Icon;
            lblPassIcon.Location = new Point(486, 1137);
            lblPassIcon.Margin = new Padding(7, 8, 0, 8);
            lblPassIcon.Name = "lblPassIcon";
            lblPassIcon.Size = new Size(95, 95);
            lblPassIcon.SizeMode = PictureBoxSizeMode.Zoom;
            lblPassIcon.TabIndex = 8;
            lblPassIcon.TabStop = false;
            // 
            // txtPassword
            // 
            txtPassword.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPassword.Location = new Point(583, 1137);
            txtPassword.Margin = new Padding(0, 3, 2, 3);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(694, 87);
            txtPassword.TabIndex = 7;
            txtPassword.UseSystemPasswordChar = true;
            txtPassword.KeyDown += txtPassword_KeyDown;
            // 
            // Main_Menu
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.Login_Screen;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1783, 1943);
            Controls.Add(lblPassIcon);
            Controls.Add(txtPassword);
            Controls.Add(lblUserIcon);
            Controls.Add(pictureBox1);
            Controls.Add(btnLogin);
            Controls.Add(txtEmail);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(2, 3, 2, 3);
            MaximizeBox = false;
            Name = "Main_Menu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Main_Menu";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)lblUserIcon).EndInit();
            ((System.ComponentModel.ISupportInitialize)lblPassIcon).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtEmail;
        private Button btnLogin;
        private PictureBox pictureBox1;
        private PictureBox lblUserIcon;
        private PictureBox lblPassIcon;
        private TextBox txtPassword;
    }
}