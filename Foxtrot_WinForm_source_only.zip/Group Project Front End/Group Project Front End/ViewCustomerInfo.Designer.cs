﻿namespace Group_Project_Front_End
{
    partial class ViewCustomerInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewCustomerInfo));
            lblHogBank = new Label();
            pictureBox1 = new PictureBox();
            pnlFnctScrn = new Panel();
            btnBack = new Button();
            txtSelect = new Label();
            dgvCustomers = new DataGridView();
            lblWelcome = new Label();
            lblInstructions = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnlFnctScrn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvCustomers).BeginInit();
            SuspendLayout();
            // 
            // lblHogBank
            // 
            lblHogBank.AutoSize = true;
            lblHogBank.Font = new Font("Segoe UI", 39F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHogBank.ForeColor = Color.Transparent;
            lblHogBank.Location = new Point(583, 44);
            lblHogBank.Margin = new Padding(7, 0, 7, 0);
            lblHogBank.Name = "lblHogBank";
            lblHogBank.Size = new Size(2296, 173);
            lblHogBank.TabIndex = 1;
            lblHogBank.Text = "HOG BANK - VIEW CUSTOMER INFO";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.RazorBack1;
            pictureBox1.Location = new Point(19, 22);
            pictureBox1.Margin = new Padding(7, 8, 7, 8);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(525, 262);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pnlFnctScrn
            // 
            pnlFnctScrn.BackColor = Color.FromArgb(64, 64, 64);
            pnlFnctScrn.Controls.Add(btnBack);
            pnlFnctScrn.Controls.Add(lblHogBank);
            pnlFnctScrn.Controls.Add(pictureBox1);
            pnlFnctScrn.Dock = DockStyle.Top;
            pnlFnctScrn.Location = new Point(0, 0);
            pnlFnctScrn.Margin = new Padding(7, 8, 7, 8);
            pnlFnctScrn.Name = "pnlFnctScrn";
            pnlFnctScrn.Size = new Size(3468, 306);
            pnlFnctScrn.TabIndex = 6;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.Transparent;
            btnBack.BackgroundImage = Properties.Resources.BackArrow;
            btnBack.BackgroundImageLayout = ImageLayout.Zoom;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.ForeColor = Color.Transparent;
            btnBack.Location = new Point(3225, 22);
            btnBack.Margin = new Padding(7, 8, 7, 8);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(233, 262);
            btnBack.TabIndex = 105;
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // txtSelect
            // 
            txtSelect.AutoSize = true;
            txtSelect.FlatStyle = FlatStyle.Flat;
            txtSelect.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtSelect.Location = new Point(97, 394);
            txtSelect.Margin = new Padding(7, 0, 7, 0);
            txtSelect.Name = "txtSelect";
            txtSelect.Size = new Size(817, 116);
            txtSelect.TabIndex = 20;
            txtSelect.Text = "Select a Customer:";
            // 
            // dgvCustomers
            // 
            dgvCustomers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCustomers.Location = new Point(155, 569);
            dgvCustomers.Margin = new Padding(7, 8, 7, 8);
            dgvCustomers.Name = "dgvCustomers";
            dgvCustomers.RowHeadersWidth = 102;
            dgvCustomers.Size = new Size(1413, 1399);
            dgvCustomers.TabIndex = 21;
            dgvCustomers.CellClick += dgvCustomers_CellClick;
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblWelcome.ForeColor = Color.FromArgb(177, 29, 41);
            lblWelcome.Location = new Point(1690, 372);
            lblWelcome.Margin = new Padding(7, 0, 7, 0);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(629, 159);
            lblWelcome.TabIndex = 22;
            lblWelcome.Text = "Welcome!";
            // 
            // lblInstructions
            // 
            lblInstructions.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblInstructions.ForeColor = Color.Black;
            lblInstructions.Location = new Point(1710, 590);
            lblInstructions.Margin = new Padding(7, 0, 7, 0);
            lblInstructions.Name = "lblInstructions";
            lblInstructions.Size = new Size(1496, 1399);
            lblInstructions.TabIndex = 23;
            lblInstructions.Text = resources.GetString("lblInstructions.Text");
            // 
            // ViewCustomerInfo
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(3468, 2137);
            Controls.Add(lblInstructions);
            Controls.Add(lblWelcome);
            Controls.Add(dgvCustomers);
            Controls.Add(txtSelect);
            Controls.Add(pnlFnctScrn);
            Margin = new Padding(7, 8, 7, 8);
            MaximizeBox = false;
            Name = "ViewCustomerInfo";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ViewCustomerInfo";
            Load += ViewCustomerInfo_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnlFnctScrn.ResumeLayout(false);
            pnlFnctScrn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvCustomers).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblHogBank;
        private PictureBox pictureBox1;
        private Panel pnlFnctScrn;
        private Label txtSelect;
        private DataGridView dgvCustomers;
        private Button btnBack;
        private Label lblWelcome;
        private Label lblInstructions;
    }
}