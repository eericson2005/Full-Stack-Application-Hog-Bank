﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group_Project_Front_End
{
    public partial class FunctionScreen : Form
    {
        public FunctionScreen()
        {
            InitializeComponent();
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            Deposit d = new Deposit();         // create the new form
            d.Owner = this;                    // Make this form owner for back button
            d.Show();                          // show it
            this.Hide();
        }

        private void btnWithdrawal_Click(object sender, EventArgs e)
        {
            Withdrawal w = new Withdrawal();    // create the new form
            w.Owner = this;                     // Make this form owner for back button
            w.Show();                           // show it
            this.Hide();
        }

        private void btnCreateAcct_Click(object sender, EventArgs e)
        {
            CreateAccount ca = new CreateAccount();     // create the new form
            ca.Owner = this;                            // Make this form owner for back button
            ca.Show();                                  // show it
            this.Hide();
        }

        private void btnCreateCustomer_Click(object sender, EventArgs e)
        {
            CreateCustomer cc = new CreateCustomer();   // create the new form
            cc.Owner = this;                            // Make this form owner for back button
            cc.Show();                                  // show it
            this.Hide();
        }

        private void btnViewCustomerInfo_Click(object sender, EventArgs e)
        {
            ViewCustomerInfo vci = new ViewCustomerInfo();  // create the new form
            vci.Owner = this;                               // Make this form owner for back button
            vci.Show();                                     // show it
            this.Hide();
        }

        // Back button
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the current form

            if (this.Owner != null)
            {
                this.Owner.Show(); // Show the form that opened this one
            }
            else
            {
                // Bring back to login if no owner established
                Application.OpenForms[0].Show();
            }
        }
    }
}
