﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group_Project_Front_End
{
    public partial class AccountInfo : Form
    {
        // Initialize variable to stored passed in account ID
        int selectedAccountId;
        public AccountInfo(int accountId)
        {
            InitializeComponent();
            selectedAccountId = accountId; // Store passed in variable into local variable
        }

        // Load the two dgvs based on account selection in previous form
        private void AccountInfo_Load(object sender, EventArgs e)
        {
            // Account Details dgv
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = @"
                SELECT 
                    a.AccountID,
                    at.AccountType,
                    a.Balance,
                    a.StartDate,
                    a.Description,
                    a.Principal,
                    a.[Interest/Return],
                    a.Term
                FROM Account a
                JOIN AccountType at ON a.AccountTypeID = at.AccountTypeID
                WHERE a.AccountID = @AccountID
            ";
            cmd.Parameters.Add("@AccountID", SqlDbType.Int).Value = selectedAccountId;

            // Store query results in the datatable
            DataTable dtAccount = new DataTable();
            Walton_DB.FillDataTable_ViaCmd(ref dtAccount, ref cmd);

            // Vertical table setup
            DataTable dtAccountVertical = new DataTable();
            dtAccountVertical.Columns.Add("Field");
            dtAccountVertical.Columns.Add("Value");

            if (dtAccount.Rows.Count > 0)
            {
                DataRow source = dtAccount.Rows[0];
                dtAccountVertical.Rows.Add("AccountID", source["AccountID"]);
                dtAccountVertical.Rows.Add("AccountType", source["AccountType"]);
                dtAccountVertical.Rows.Add("Balance", source["Balance"]);
                dtAccountVertical.Rows.Add("StartDate", Convert.ToDateTime(source["StartDate"]).ToString("MM/dd/yyyy"));
                dtAccountVertical.Rows.Add("Description", source["Description"]);
                dtAccountVertical.Rows.Add("Principal", source["Principal"]);
                dtAccountVertical.Rows.Add("Interest/Return", source["Interest/Return"]);
                dtAccountVertical.Rows.Add("Term", source["Term"]);
            }

            dgvAccountDetails.DataSource = dtAccountVertical; // Put into dgv
            dgvAccountDetails.ClearSelection(); // Stop autofocusing
            dgvAccountDetails.CurrentCell = null;

            // -----------------------------------FORMATING START-----------------------------------
            dgvAccountDetails.DefaultCellStyle.Font = new Font("Segoe UI", 16);
            dgvAccountDetails.ColumnHeadersVisible = false;
            dgvAccountDetails.Columns["Field"].DefaultCellStyle.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            dgvAccountDetails.RowHeadersVisible = false;
            dgvAccountDetails.AllowUserToAddRows = false;
            dgvAccountDetails.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            dgvAccountDetails.GridColor = Color.Black;
            dgvAccountDetails.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgvAccountDetails.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvAccountDetails.BackgroundColor = this.BackColor;
            dgvAccountDetails.BorderStyle = BorderStyle.None;
            dgvAccountDetails.ReadOnly = true;
            dgvAccountDetails.TabStop = false;
            dgvAccountDetails.Enabled = false;

            if (dgvAccountDetails.Columns.Contains("AccountID")) // Re-show the account id in the details
                dgvAccountDetails.Columns["AccountID"].Visible = true;
            // -----------------------------------FORMATING END-----------------------------------

            // Extract account type for dynamic form header
            lblSQLAccountType.Text = $"{dtAccount.Rows[0]["AccountType"]}";

            // Transaction dgv
            cmd = new SqlCommand();
            cmd.CommandText = @"
                SELECT 
                    t.TransactionDate,
                    t.TransactionType,
                    t.AmountTransferred,
                    l.LocationAddress,
                    l.RoutingNumber,
                    e.EmployeeLastName       
                FROM [Transaction] t
                JOIN Location l ON t.LocationID = l.LocationID
                JOIN Employee e ON t.EmployeeID = e.EmployeeID
                WHERE t.AccountID = @AccountID
                ORDER BY t.TransactionDate DESC
            ";
            cmd.Parameters.Add("@AccountID", SqlDbType.Int).Value = selectedAccountId;

            // Store query results in the datatable
            DataTable dtTx = new DataTable();
            Walton_DB.FillDataTable_ViaCmd(ref dtTx, ref cmd);
            dgvTransactionHistory.DataSource = dtTx; // Put it into dgv

            dgvTransactionHistory.ClearSelection(); // Stop auto focus
            dgvTransactionHistory.CurrentCell = null;

            // -----------------------------------FORMATTING START-----------------------------------
            dgvTransactionHistory.DefaultCellStyle.Font = new Font("Segoe UI", 16);
            dgvTransactionHistory.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            dgvTransactionHistory.RowHeadersVisible = false;
            dgvTransactionHistory.AllowUserToAddRows = false;
            dgvTransactionHistory.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            dgvTransactionHistory.GridColor = Color.Black;
            dgvTransactionHistory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgvTransactionHistory.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvTransactionHistory.BackgroundColor = this.BackColor;
            dgvTransactionHistory.BorderStyle = BorderStyle.None;
            dgvTransactionHistory.ColumnHeadersVisible = true;
            dgvTransactionHistory.ReadOnly = true;
            // -----------------------------------FORMATTING END-----------------------------------
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the current form

            if (this.Owner != null)
            {
                this.Owner.Show(); // Show the form that opened this one
            }
            else
            {
                // Bring back to login if no owner established
                Application.OpenForms[0].Show();
            }
        }
    }
}
