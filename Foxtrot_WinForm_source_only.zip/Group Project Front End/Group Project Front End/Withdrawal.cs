﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group_Project_Front_End
{
    public partial class Withdrawal : Form
    {
        public Withdrawal()
        {
            InitializeComponent();
        }

        // ---------------------ENTER PRESS EVENTS START---------------------
        //Move cursor to next text box on enter press
        private void txtAccountID_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtWithdrawalAmount.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true; // Prevent the default ding sound
            }
        }

        // Move cursor to final text box on enter press
        private void txtWithdrawalAmount_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtLocationID.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true; // Prevent the default ding sound
            }
        }

        // Submit on Enter press
        private void txtLocationID_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Call Submit method
                btnSubmit_Click(sender, e);
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }
        // ---------------------ENTER PRESS EVENTS END---------------------

        // Submit method
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            decimal withdrawalAmount;

            // check that all info has been entered and withdrawal amount is valid
            if (!string.IsNullOrWhiteSpace(txtAccountID.Text) &&
                !string.IsNullOrWhiteSpace(txtWithdrawalAmount.Text) &&
                !string.IsNullOrWhiteSpace(txtLocationID.Text) &&
                decimal.TryParse(txtWithdrawalAmount.Text, out withdrawalAmount) &&
                withdrawalAmount >= 0)
            {
                // SQL Command (Checks for insufficient funds)
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = @"
                    IF EXISTS (
                        SELECT 1 FROM Account
                        WHERE AccountID = @AccountID AND Balance >= @Amount
                    )
                    BEGIN
                        UPDATE Account
                        SET Balance = Balance - @Amount
                        WHERE AccountID = @AccountID;

                        INSERT INTO [Transaction] (
                            EmployeeID,
                            LocationID,
                            AccountID,
                            TransactionDate,
                            TransactionType,
                            AmountTransferred
                        )
                        VALUES (
                            @EmployeeID,
                            @LocationID,
                            @AccountID,
                            GETDATE(),
                            'Withdrawal',
                            @Amount
                        );
                    END
                    ELSE
                    BEGIN
                        RAISERROR('Insufficient funds.', 16, 1);
                    END;
                ";

                // Add SQL parameters
                cmd.Parameters.Add("@AccountID", SqlDbType.Int).Value = Convert.ToInt32(txtAccountID.Text);
                cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = withdrawalAmount;
                cmd.Parameters["@Amount"].Precision = 10;
                cmd.Parameters["@Amount"].Scale = 2;
                cmd.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = Session.EmployeeID;
                cmd.Parameters.Add("@LocationID", SqlDbType.Int).Value = Convert.ToInt32(txtLocationID.Text);

                // Execute the command and check for success
                bool success = Walton_DB.ExecSqlCommand(ref cmd);

                if (success)
                {
                    MessageBox.Show("Withdrawal successful.");
                    btnBack_Click(sender, e); // Send you back to main function screen
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Insufficient funds or failed to complete withdrawal.");
                }
            }
            else
            {
                MessageBox.Show("Please enter values for all fields and ensure withdrawal amount is non-negative.");
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the current form

            if (this.Owner != null)
            {
                this.Owner.Show(); // Show the form that opened this one
            }
            else
            {
                // Bring back to login if no owner established
                Application.OpenForms[0].Show();
            }
        }
    }
}
