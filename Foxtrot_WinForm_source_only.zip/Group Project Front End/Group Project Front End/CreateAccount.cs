﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group_Project_Front_End
{
    public partial class CreateAccount : Form
    {
        public CreateAccount()
        {
            InitializeComponent();
        }

        // ---------------------ENTER PRESS EVENTS START---------------------
        // Enter press to next
        private void txtCustomerID_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtAccountType.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true; // Prevent the default ding sound
            }
        }

        // Enter press to next
        private void txtAccountType_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtInitialDeposit.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true; // Prevent the default ding sound
            }
        }

        // Enter press to next
        private void txtInitialDeposit_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtLocation.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true; // Prevent the default ding sound
            }
        }

        // Enter press to next
        private void txtLocation_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtDescription.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true; // Prevent the default ding sound
            }
        }

        // Enter press to next
        private void txtDescription_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtPrincipal.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true; // Prevent the default ding sound
            }
        }

        // Enter press to next
        private void txtPrincipal_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtInterestReturn.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true; // Prevent the default ding sound
            }
        }

        // Enter press to next
        private void txtInterestReturn_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtTerm.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true; // Prevent the default ding sound
            }
        }

        // Enter press to submit
        private void txtTerm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnSubmit_Click(sender, e); // Call submit method
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }

        // ---------------------ENTER PRESS EVENTS END---------------------

        // Click event for submission
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // Sets up a variable to check if account if checking
            bool isChecking = txtAccountType.Text == "1";

            // Shared validation
            bool basicValid =
                !string.IsNullOrWhiteSpace(txtCustomerID.Text) &&
                !string.IsNullOrWhiteSpace(txtAccountType.Text) &&
                !string.IsNullOrWhiteSpace(txtInitialDeposit.Text) &&
                !string.IsNullOrWhiteSpace(txtLocation.Text) &&
                !string.IsNullOrWhiteSpace(txtDescription.Text);

            // Validation for non checking
            bool extendedValid =
                !string.IsNullOrWhiteSpace(txtPrincipal.Text) &&
                !string.IsNullOrWhiteSpace(txtInterestReturn.Text) &&
                !string.IsNullOrWhiteSpace(txtTerm.Text);

            // Numeric validation
            decimal balance = 0, principal = 0, interestReturn = 0;
            int term = 0;

            // Checking shared balance field
            bool numericValid =
                decimal.TryParse(txtInitialDeposit.Text, out balance) && balance >= 0;

            // Checking non checking attributes
            if (!isChecking && extendedValid)
            {
                numericValid = numericValid &&
                    decimal.TryParse(txtPrincipal.Text, out principal) && principal >= 0 &&
                    decimal.TryParse(txtInterestReturn.Text, out interestReturn) && interestReturn >= 0 && interestReturn <= 1 &&
                    int.TryParse(txtTerm.Text, out term) && term >= 0 && term <= 360;
            }

            // Checking that all conditions are met
            if (basicValid && (isChecking || (!isChecking && extendedValid)) && numericValid)
            {
                // Constructing SQL command
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = @"
                DECLARE @NewAccountID INT;

                INSERT INTO Account (
                    CustomerID,
                    AccountTypeID,
                    Balance,
                    StartDate,
                    Description,
                    Principal,
                    [Interest/Return],
                    Term
                )
                VALUES (
                    @CustomerID,
                    @AccountTypeID,
                    @Balance,
                    GETDATE(),
                    @Description,
                    @Principal,
                    @InterestReturn,
                    @Term
                );

                SET @NewAccountID = SCOPE_IDENTITY();

                INSERT INTO [Transaction] (
                    EmployeeID,
                    LocationID,
                    AccountID,
                    TransactionDate,
                    TransactionType,
                    AmountTransferred
                )
                VALUES (
                    @EmployeeID,
                    @LocationID,
                    @NewAccountID,
                    GETDATE(),
                    @TransactionType,
                    @AmountTransferred
                );
            ";

                    // Shared parameters
                    cmd.Parameters.Add("@CustomerID", SqlDbType.Int).Value = Convert.ToInt32(txtCustomerID.Text);
                    cmd.Parameters.Add("@AccountTypeID", SqlDbType.Int).Value = Convert.ToInt32(txtAccountType.Text);
                    cmd.Parameters.Add("@Balance", SqlDbType.Decimal).Value = balance;
                    cmd.Parameters["@Balance"].Precision = 10;
                    cmd.Parameters["@Balance"].Scale = 2;
                    cmd.Parameters.Add("@Description", SqlDbType.VarChar, 200).Value = txtDescription.Text;
                    cmd.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = Session.EmployeeID;
                    cmd.Parameters.Add("@LocationID", SqlDbType.Int).Value = Convert.ToInt32(txtLocation.Text);
                    cmd.Parameters.Add("@TransactionType", SqlDbType.VarChar, 30).Value = "Deposit";
                    cmd.Parameters.Add("@AmountTransferred", SqlDbType.Decimal).Value = balance;
                    cmd.Parameters["@AmountTransferred"].Precision = 10;
                    cmd.Parameters["@AmountTransferred"].Scale = 2;

                    // If its checking, set all non checking fields to null
                    if (isChecking)
                    {
                        cmd.Parameters.Add("@Principal", SqlDbType.Decimal).Value = DBNull.Value;
                        cmd.Parameters["@Principal"].Precision = 10;
                        cmd.Parameters["@Principal"].Scale = 2;
                        cmd.Parameters.Add("@InterestReturn", SqlDbType.Decimal).Value = DBNull.Value;
                        cmd.Parameters["@InterestReturn"].Precision = 4;
                        cmd.Parameters["@InterestReturn"].Scale = 4;
                        cmd.Parameters.Add("@Term", SqlDbType.Int).Value = DBNull.Value;
                    }
                    // if its non checking, process entered values
                    else
                    {
                        cmd.Parameters.Add("@Principal", SqlDbType.Decimal).Value = principal;
                        cmd.Parameters["@Principal"].Precision = 10;
                        cmd.Parameters["@Principal"].Scale = 2;
                        cmd.Parameters.Add("@InterestReturn", SqlDbType.Decimal).Value = interestReturn;
                        cmd.Parameters["@InterestReturn"].Precision = 4;
                        cmd.Parameters["@InterestReturn"].Scale = 4;
                        cmd.Parameters.Add("@Term", SqlDbType.Int).Value = term;
                    }

                    if (Walton_DB.ExecSqlCommand(ref cmd))
                    {
                        MessageBox.Show("Account and transaction saved successfully.");
                        btnBack_Click(sender, e); // Send you back to main function screen
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Database error occurred.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            else
            {
                // Conditional message for checking vs. non checking
                MessageBox.Show(isChecking ?
                    "Please enter valid values for the first five fields (no negative numbers)." :
                    "Please enter valid values for all fields (no negative numbers)."
                );
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the current form

            if (this.Owner != null)
            {
                this.Owner.Show(); // Show the form that opened this one
            }
            else
            {
                // Bring back to login if no owner established
                Application.OpenForms[0].Show();
            }
        }
    }
}
