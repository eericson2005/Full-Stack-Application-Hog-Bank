﻿namespace Group_Project_Front_End
{
    partial class CreateAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblHogBank = new Label();
            pictureBox1 = new PictureBox();
            pnlFnctScrn = new Panel();
            txtCustomerID = new TextBox();
            btnSubmit = new Button();
            lblCustomerID = new Label();
            txtAccountType = new TextBox();
            lblAccountType = new Label();
            txtInitialDeposit = new TextBox();
            lblInitialDeposit = new Label();
            txtDescription = new TextBox();
            lblDescription = new Label();
            txtPrincipal = new TextBox();
            lblPrincipal = new Label();
            txtInterestReturn = new TextBox();
            lblInterestReturn = new Label();
            txtTerm = new TextBox();
            lblTerm = new Label();
            txtLocation = new TextBox();
            lblLocation = new Label();
            lblCustomerIDInfo = new Label();
            lblAccountTypeInfo = new Label();
            lblInitialDepositInfo = new Label();
            lblPrincipalInfo = new Label();
            lblInterestInfo = new Label();
            lblTermInfo = new Label();
            lblDescriptionInfo = new Label();
            lblLocationIDInfo = new Label();
            lblWarning = new Label();
            panel1 = new Panel();
            btnBack = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnlFnctScrn.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // lblHogBank
            // 
            lblHogBank.AutoSize = true;
            lblHogBank.Font = new Font("Segoe UI", 39F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHogBank.ForeColor = Color.Transparent;
            lblHogBank.Location = new Point(240, 16);
            lblHogBank.Name = "lblHogBank";
            lblHogBank.Size = new Size(799, 70);
            lblHogBank.TabIndex = 1;
            lblHogBank.Text = "HOG BANK - CREATE ACCOUNT";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.RazorBack1;
            pictureBox1.Location = new Point(8, 8);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(216, 96);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pnlFnctScrn
            // 
            pnlFnctScrn.BackColor = Color.FromArgb(64, 64, 64);
            pnlFnctScrn.Controls.Add(btnBack);
            pnlFnctScrn.Controls.Add(lblHogBank);
            pnlFnctScrn.Controls.Add(pictureBox1);
            pnlFnctScrn.Dock = DockStyle.Top;
            pnlFnctScrn.Location = new Point(0, 0);
            pnlFnctScrn.Name = "pnlFnctScrn";
            pnlFnctScrn.Size = new Size(1428, 112);
            pnlFnctScrn.TabIndex = 6;
            // 
            // txtCustomerID
            // 
            txtCustomerID.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtCustomerID.Location = new Point(312, 164);
            txtCustomerID.Name = "txtCustomerID";
            txtCustomerID.Size = new Size(500, 50);
            txtCustomerID.TabIndex = 24;
            txtCustomerID.KeyDown += txtCustomerID_KeyDown;
            // 
            // btnSubmit
            // 
            btnSubmit.BackColor = Color.FromArgb(177, 29, 41);
            btnSubmit.FlatAppearance.BorderColor = Color.FromArgb(64, 64, 64);
            btnSubmit.FlatAppearance.BorderSize = 3;
            btnSubmit.FlatStyle = FlatStyle.Flat;
            btnSubmit.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSubmit.ForeColor = Color.White;
            btnSubmit.Location = new Point(88, 664);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(168, 64);
            btnSubmit.TabIndex = 23;
            btnSubmit.Text = "SUBMIT";
            btnSubmit.UseVisualStyleBackColor = false;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // lblCustomerID
            // 
            lblCustomerID.AutoSize = true;
            lblCustomerID.Font = new Font("Segoe UI", 26.25F);
            lblCustomerID.Location = new Point(88, 160);
            lblCustomerID.Name = "lblCustomerID";
            lblCustomerID.Size = new Size(222, 47);
            lblCustomerID.TabIndex = 22;
            lblCustomerID.Text = "Customer ID:";
            // 
            // txtAccountType
            // 
            txtAccountType.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtAccountType.Location = new Point(328, 256);
            txtAccountType.Name = "txtAccountType";
            txtAccountType.Size = new Size(500, 50);
            txtAccountType.TabIndex = 26;
            txtAccountType.KeyDown += txtAccountType_KeyDown;
            // 
            // lblAccountType
            // 
            lblAccountType.AutoSize = true;
            lblAccountType.Font = new Font("Segoe UI", 26.25F);
            lblAccountType.Location = new Point(88, 252);
            lblAccountType.Name = "lblAccountType";
            lblAccountType.Size = new Size(238, 47);
            lblAccountType.TabIndex = 25;
            lblAccountType.Text = "Account Type:";
            // 
            // txtInitialDeposit
            // 
            txtInitialDeposit.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtInitialDeposit.Location = new Point(328, 352);
            txtInitialDeposit.Name = "txtInitialDeposit";
            txtInitialDeposit.Size = new Size(368, 50);
            txtInitialDeposit.TabIndex = 28;
            txtInitialDeposit.KeyDown += txtInitialDeposit_KeyDown;
            // 
            // lblInitialDeposit
            // 
            lblInitialDeposit.AutoSize = true;
            lblInitialDeposit.Font = new Font("Segoe UI", 26.25F);
            lblInitialDeposit.Location = new Point(88, 348);
            lblInitialDeposit.Name = "lblInitialDeposit";
            lblInitialDeposit.Size = new Size(241, 47);
            lblInitialDeposit.TabIndex = 27;
            lblInitialDeposit.Text = "Initial Deposit:";
            // 
            // txtDescription
            // 
            txtDescription.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtDescription.Location = new Point(296, 544);
            txtDescription.Multiline = true;
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(528, 50);
            txtDescription.TabIndex = 30;
            // 
            // lblDescription
            // 
            lblDescription.AutoSize = true;
            lblDescription.Font = new Font("Segoe UI", 26.25F);
            lblDescription.Location = new Point(88, 540);
            lblDescription.Name = "lblDescription";
            lblDescription.Size = new Size(204, 47);
            lblDescription.TabIndex = 29;
            lblDescription.Text = "Description:";
            // 
            // txtPrincipal
            // 
            txtPrincipal.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPrincipal.Location = new Point(1064, 296);
            txtPrincipal.Name = "txtPrincipal";
            txtPrincipal.Size = new Size(176, 50);
            txtPrincipal.TabIndex = 32;
            txtPrincipal.KeyDown += txtPrincipal_KeyDown;
            // 
            // lblPrincipal
            // 
            lblPrincipal.AutoSize = true;
            lblPrincipal.Font = new Font("Segoe UI", 26.25F);
            lblPrincipal.Location = new Point(904, 292);
            lblPrincipal.Name = "lblPrincipal";
            lblPrincipal.Size = new Size(159, 47);
            lblPrincipal.TabIndex = 31;
            lblPrincipal.Text = "Principal:";
            // 
            // txtInterestReturn
            // 
            txtInterestReturn.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtInterestReturn.Location = new Point(1168, 392);
            txtInterestReturn.Name = "txtInterestReturn";
            txtInterestReturn.Size = new Size(176, 50);
            txtInterestReturn.TabIndex = 34;
            txtInterestReturn.KeyDown += txtInterestReturn_KeyDown;
            // 
            // lblInterestReturn
            // 
            lblInterestReturn.AutoSize = true;
            lblInterestReturn.Font = new Font("Segoe UI", 26.25F);
            lblInterestReturn.Location = new Point(904, 388);
            lblInterestReturn.Name = "lblInterestReturn";
            lblInterestReturn.Size = new Size(260, 47);
            lblInterestReturn.TabIndex = 33;
            lblInterestReturn.Text = "Interest/Return:";
            // 
            // txtTerm
            // 
            txtTerm.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtTerm.Location = new Point(1008, 484);
            txtTerm.Name = "txtTerm";
            txtTerm.Size = new Size(176, 50);
            txtTerm.TabIndex = 36;
            txtTerm.KeyDown += txtTerm_KeyDown;
            // 
            // lblTerm
            // 
            lblTerm.AutoSize = true;
            lblTerm.Font = new Font("Segoe UI", 26.25F);
            lblTerm.Location = new Point(904, 480);
            lblTerm.Name = "lblTerm";
            lblTerm.Size = new Size(103, 47);
            lblTerm.TabIndex = 35;
            lblTerm.Text = "Term:";
            // 
            // txtLocation
            // 
            txtLocation.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtLocation.Location = new Point(288, 452);
            txtLocation.Name = "txtLocation";
            txtLocation.Size = new Size(368, 50);
            txtLocation.TabIndex = 29;
            txtLocation.KeyDown += txtLocation_KeyDown;
            // 
            // lblLocation
            // 
            lblLocation.AutoSize = true;
            lblLocation.Font = new Font("Segoe UI", 26.25F);
            lblLocation.Location = new Point(88, 448);
            lblLocation.Name = "lblLocation";
            lblLocation.Size = new Size(204, 47);
            lblLocation.TabIndex = 37;
            lblLocation.Text = "Location ID:";
            // 
            // lblCustomerIDInfo
            // 
            lblCustomerIDInfo.AutoSize = true;
            lblCustomerIDInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCustomerIDInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblCustomerIDInfo.Location = new Point(112, 216);
            lblCustomerIDInfo.Name = "lblCustomerIDInfo";
            lblCustomerIDInfo.Size = new Size(331, 25);
            lblCustomerIDInfo.TabIndex = 38;
            lblCustomerIDInfo.Text = "Customer ID from View Customer Info";
            // 
            // lblAccountTypeInfo
            // 
            lblAccountTypeInfo.AutoSize = true;
            lblAccountTypeInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAccountTypeInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblAccountTypeInfo.Location = new Point(112, 312);
            lblAccountTypeInfo.Name = "lblAccountTypeInfo";
            lblAccountTypeInfo.Size = new Size(282, 25);
            lblAccountTypeInfo.TabIndex = 39;
            lblAccountTypeInfo.Text = "Checking: 1, Investing: 2, Loan: 3";
            // 
            // lblInitialDepositInfo
            // 
            lblInitialDepositInfo.AutoSize = true;
            lblInitialDepositInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblInitialDepositInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblInitialDepositInfo.Location = new Point(112, 408);
            lblInitialDepositInfo.Name = "lblInitialDepositInfo";
            lblInitialDepositInfo.Size = new Size(416, 25);
            lblInitialDepositInfo.TabIndex = 40;
            lblInitialDepositInfo.Text = "Non-Negative amount to open the account with";
            // 
            // lblPrincipalInfo
            // 
            lblPrincipalInfo.AutoSize = true;
            lblPrincipalInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPrincipalInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblPrincipalInfo.Location = new Point(928, 348);
            lblPrincipalInfo.Name = "lblPrincipalInfo";
            lblPrincipalInfo.Size = new Size(429, 25);
            lblPrincipalInfo.TabIndex = 42;
            lblPrincipalInfo.Text = "Principal amount (same as initial deposit amount)";
            // 
            // lblInterestInfo
            // 
            lblInterestInfo.AutoSize = true;
            lblInterestInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblInterestInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblInterestInfo.Location = new Point(928, 444);
            lblInterestInfo.Name = "lblInterestInfo";
            lblInterestInfo.Size = new Size(301, 25);
            lblInterestInfo.TabIndex = 43;
            lblInterestInfo.Text = "Non-Negative 0 - 1 interest/return";
            // 
            // lblTermInfo
            // 
            lblTermInfo.AutoSize = true;
            lblTermInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTermInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblTermInfo.Location = new Point(928, 540);
            lblTermInfo.Name = "lblTermInfo";
            lblTermInfo.Size = new Size(238, 25);
            lblTermInfo.TabIndex = 44;
            lblTermInfo.Text = "Term of the loan in months";
            // 
            // lblDescriptionInfo
            // 
            lblDescriptionInfo.AutoSize = true;
            lblDescriptionInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDescriptionInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblDescriptionInfo.Location = new Point(112, 600);
            lblDescriptionInfo.Name = "lblDescriptionInfo";
            lblDescriptionInfo.Size = new Size(661, 25);
            lblDescriptionInfo.TabIndex = 45;
            lblDescriptionInfo.Text = "Short description of account (press Enter for next line; Arrow Up for previous)";
            // 
            // lblLocationIDInfo
            // 
            lblLocationIDInfo.AutoSize = true;
            lblLocationIDInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblLocationIDInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblLocationIDInfo.Location = new Point(112, 504);
            lblLocationIDInfo.Name = "lblLocationIDInfo";
            lblLocationIDInfo.Size = new Size(249, 25);
            lblLocationIDInfo.TabIndex = 46;
            lblLocationIDInfo.Text = "Bentonvl: 1, Rogrs: 2, Fayvl: 3";
            // 
            // lblWarning
            // 
            lblWarning.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblWarning.ForeColor = Color.FromArgb(177, 29, 41);
            lblWarning.Location = new Point(56, 24);
            lblWarning.Name = "lblWarning";
            lblWarning.Size = new Size(368, 72);
            lblWarning.TabIndex = 47;
            lblWarning.Text = "Only enter values for these fields if Account Type = 2 or 3";
            lblWarning.TextAlign = ContentAlignment.TopCenter;
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(lblWarning);
            panel1.Location = new Point(888, 184);
            panel1.Name = "panel1";
            panel1.Size = new Size(480, 416);
            panel1.TabIndex = 48;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.Transparent;
            btnBack.BackgroundImage = Properties.Resources.BackArrow;
            btnBack.BackgroundImageLayout = ImageLayout.Zoom;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.ForeColor = Color.Transparent;
            btnBack.Location = new Point(1328, 8);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(96, 96);
            btnBack.TabIndex = 103;
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // CreateAccount
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1428, 782);
            Controls.Add(lblLocationIDInfo);
            Controls.Add(lblDescriptionInfo);
            Controls.Add(lblTermInfo);
            Controls.Add(lblInterestInfo);
            Controls.Add(lblPrincipalInfo);
            Controls.Add(lblInitialDepositInfo);
            Controls.Add(lblAccountTypeInfo);
            Controls.Add(lblCustomerIDInfo);
            Controls.Add(txtLocation);
            Controls.Add(lblLocation);
            Controls.Add(txtTerm);
            Controls.Add(lblTerm);
            Controls.Add(txtInterestReturn);
            Controls.Add(lblInterestReturn);
            Controls.Add(txtPrincipal);
            Controls.Add(lblPrincipal);
            Controls.Add(txtDescription);
            Controls.Add(lblDescription);
            Controls.Add(txtInitialDeposit);
            Controls.Add(lblInitialDeposit);
            Controls.Add(txtAccountType);
            Controls.Add(lblAccountType);
            Controls.Add(txtCustomerID);
            Controls.Add(btnSubmit);
            Controls.Add(lblCustomerID);
            Controls.Add(pnlFnctScrn);
            Controls.Add(panel1);
            MaximizeBox = false;
            Name = "CreateAccount";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CreateAccount";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnlFnctScrn.ResumeLayout(false);
            pnlFnctScrn.PerformLayout();
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblHogBank;
        private PictureBox pictureBox1;
        private Panel pnlFnctScrn;
        private TextBox txtCustomerID;
        private Button btnSubmit;
        private Label lblCustomerID;
        private TextBox txtAccountType;
        private Label lblAccountType;
        private TextBox txtInitialDeposit;
        private Label lblInitialDeposit;
        private TextBox txtDescription;
        private Label lblDescription;
        private TextBox txtPrincipal;
        private Label lblPrincipal;
        private TextBox txtInterestReturn;
        private Label lblInterestReturn;
        private TextBox txtTerm;
        private Label lblTerm;
        private TextBox txtLocation;
        private Label lblLocation;
        private Label lblCustomerIDInfo;
        private Label lblAccountTypeInfo;
        private Label lblInitialDepositInfo;
        private Label lblPrincipalInfo;
        private Label lblInterestInfo;
        private Label lblTermInfo;
        private Label lblDescriptionInfo;
        private Label lblLocationIDInfo;
        private Label lblWarning;
        private Panel panel1;
        private Button btnBack;
    }
}