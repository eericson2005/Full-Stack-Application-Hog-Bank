﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group_Project_Front_End
{
    public partial class Deposit : Form
    {
        public Deposit()
        {
            InitializeComponent();
        }

        // ---------------------ENTER PRESS EVENTS START---------------------
        // Enter to next
        private void txtAccountID_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtDepositAmount.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true; // Prevent the default ding sound
            }
        }

        // Enter to next
        private void txtDepositAmount_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtLocationID.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true; // Prevent the default ding sound
            }
        }

        // Enter to next
        private void txtLocationID_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (!string.IsNullOrWhiteSpace(txtAccountID.Text) &&
                    !string.IsNullOrWhiteSpace(txtDepositAmount.Text) &&
                    !string.IsNullOrWhiteSpace(txtLocationID.Text))
                {
                    btnSubmit.PerformClick(); // simulate submit button click
                }
                else
                {
                    MessageBox.Show("Please enter values for all fields");
                }

                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }
        // ---------------------ENTER PRESS EVENTS END---------------------

        // Submit method
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            decimal depositAmount;

            if (!string.IsNullOrWhiteSpace(txtAccountID.Text) &&
                !string.IsNullOrWhiteSpace(txtDepositAmount.Text) &&
                !string.IsNullOrWhiteSpace(txtLocationID.Text) &&
                decimal.TryParse(txtDepositAmount.Text, out depositAmount) &&
                depositAmount >= 0)
            {
                // Prepare SQL command using parameters
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = @"
                    UPDATE Account
                    SET Balance = Balance + @Amount
                    WHERE AccountID = @AccountID;

                    INSERT INTO [Transaction] (
                        EmployeeID,
                        LocationID,
                        AccountID,
                        TransactionDate,
                        TransactionType,
                        AmountTransferred
                    )
                    VALUES (
                        @EmployeeID,
                        @LocationID,
                        @AccountID,
                        GETDATE(),
                        'Deposit',
                        @Amount
                    );
                ";

                cmd.Parameters.Add("@AccountID", SqlDbType.Int).Value = Convert.ToInt32(txtAccountID.Text);
                cmd.Parameters.Add("@Amount", SqlDbType.Decimal).Value = depositAmount;
                cmd.Parameters["@Amount"].Precision = 10;
                cmd.Parameters["@Amount"].Scale = 2;
                cmd.Parameters.Add("@EmployeeID", SqlDbType.Int).Value = Session.EmployeeID;
                cmd.Parameters.Add("@LocationID", SqlDbType.Int).Value = Convert.ToInt32(txtLocationID.Text);

                bool success = Walton_DB.ExecSqlCommand(ref cmd);

                if (success)
                {
                    MessageBox.Show("Deposit successful.");
                    btnBack_Click(sender, e); // Send you back to main function screen
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Failed to complete deposit.");
                }
            }
            else
            {
                MessageBox.Show("Please enter values for all fields and ensure deposit amount is non-negative.");
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the current form

            if (this.Owner != null)
            {
                this.Owner.Show(); // Show the form that opened this one
            }
            else
            {
                // Bring back to login if no owner established
                Application.OpenForms[0].Show();
            }
        }
    }
}
