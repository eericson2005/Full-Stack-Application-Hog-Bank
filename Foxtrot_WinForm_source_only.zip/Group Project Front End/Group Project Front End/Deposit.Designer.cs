﻿namespace Group_Project_Front_End
{
    partial class Deposit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblHogBank = new Label();
            pictureBox1 = new PictureBox();
            pnlFnctScrn = new Panel();
            btnBack = new Button();
            lblAccountID = new Label();
            lblDepositAmount = new Label();
            lblLocationID = new Label();
            btnSubmit = new Button();
            txtAccountID = new TextBox();
            txtDepositAmount = new TextBox();
            txtLocationID = new TextBox();
            lblDepositAmountInfo = new Label();
            lblAccountIDInfo = new Label();
            lblLocationIDInfo = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnlFnctScrn.SuspendLayout();
            SuspendLayout();
            // 
            // lblHogBank
            // 
            lblHogBank.AutoSize = true;
            lblHogBank.Font = new Font("Segoe UI", 39F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHogBank.ForeColor = Color.Transparent;
            lblHogBank.Location = new Point(240, 16);
            lblHogBank.Name = "lblHogBank";
            lblHogBank.Size = new Size(566, 70);
            lblHogBank.TabIndex = 1;
            lblHogBank.Text = "HOG BANK - DEPOSIT";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.RazorBack1;
            pictureBox1.Location = new Point(8, 8);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(216, 96);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pnlFnctScrn
            // 
            pnlFnctScrn.BackColor = Color.FromArgb(64, 64, 64);
            pnlFnctScrn.Controls.Add(btnBack);
            pnlFnctScrn.Controls.Add(lblHogBank);
            pnlFnctScrn.Controls.Add(pictureBox1);
            pnlFnctScrn.Dock = DockStyle.Top;
            pnlFnctScrn.Location = new Point(0, 0);
            pnlFnctScrn.Name = "pnlFnctScrn";
            pnlFnctScrn.Size = new Size(984, 112);
            pnlFnctScrn.TabIndex = 6;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.Transparent;
            btnBack.BackgroundImage = Properties.Resources.BackArrow;
            btnBack.BackgroundImageLayout = ImageLayout.Zoom;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.ForeColor = Color.Transparent;
            btnBack.Location = new Point(880, 8);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(96, 96);
            btnBack.TabIndex = 101;
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // lblAccountID
            // 
            lblAccountID.AutoSize = true;
            lblAccountID.Font = new Font("Segoe UI", 26.25F);
            lblAccountID.Location = new Point(88, 160);
            lblAccountID.Name = "lblAccountID";
            lblAccountID.Size = new Size(200, 47);
            lblAccountID.TabIndex = 7;
            lblAccountID.Text = "Account ID:";
            // 
            // lblDepositAmount
            // 
            lblDepositAmount.AutoSize = true;
            lblDepositAmount.Font = new Font("Segoe UI", 26.25F);
            lblDepositAmount.Location = new Point(88, 256);
            lblDepositAmount.Name = "lblDepositAmount";
            lblDepositAmount.Size = new Size(284, 47);
            lblDepositAmount.TabIndex = 8;
            lblDepositAmount.Text = "Deposit Amount:";
            // 
            // lblLocationID
            // 
            lblLocationID.AutoSize = true;
            lblLocationID.Font = new Font("Segoe UI", 26.25F);
            lblLocationID.Location = new Point(88, 352);
            lblLocationID.Name = "lblLocationID";
            lblLocationID.Size = new Size(204, 47);
            lblLocationID.TabIndex = 9;
            lblLocationID.Text = "Location ID:";
            // 
            // btnSubmit
            // 
            btnSubmit.BackColor = Color.FromArgb(177, 29, 41);
            btnSubmit.FlatAppearance.BorderColor = Color.FromArgb(64, 64, 64);
            btnSubmit.FlatAppearance.BorderSize = 3;
            btnSubmit.FlatStyle = FlatStyle.Flat;
            btnSubmit.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSubmit.ForeColor = Color.White;
            btnSubmit.Location = new Point(88, 464);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(168, 64);
            btnSubmit.TabIndex = 10;
            btnSubmit.Text = "SUBMIT";
            btnSubmit.UseVisualStyleBackColor = false;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // txtAccountID
            // 
            txtAccountID.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtAccountID.Location = new Point(288, 160);
            txtAccountID.Name = "txtAccountID";
            txtAccountID.Size = new Size(300, 50);
            txtAccountID.TabIndex = 11;
            txtAccountID.KeyDown += txtAccountID_KeyDown;
            // 
            // txtDepositAmount
            // 
            txtDepositAmount.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtDepositAmount.Location = new Point(376, 256);
            txtDepositAmount.Name = "txtDepositAmount";
            txtDepositAmount.Size = new Size(300, 50);
            txtDepositAmount.TabIndex = 12;
            txtDepositAmount.KeyDown += txtDepositAmount_KeyDown;
            // 
            // txtLocationID
            // 
            txtLocationID.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtLocationID.Location = new Point(296, 352);
            txtLocationID.Name = "txtLocationID";
            txtLocationID.Size = new Size(300, 50);
            txtLocationID.TabIndex = 13;
            txtLocationID.KeyDown += txtLocationID_KeyDown;
            // 
            // lblDepositAmountInfo
            // 
            lblDepositAmountInfo.AutoSize = true;
            lblDepositAmountInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDepositAmountInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblDepositAmountInfo.Location = new Point(112, 312);
            lblDepositAmountInfo.Name = "lblDepositAmountInfo";
            lblDepositAmountInfo.Size = new Size(290, 25);
            lblDepositAmountInfo.TabIndex = 25;
            lblDepositAmountInfo.Text = "Non-Negative amount to deposit";
            // 
            // lblAccountIDInfo
            // 
            lblAccountIDInfo.AutoSize = true;
            lblAccountIDInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAccountIDInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblAccountIDInfo.Location = new Point(112, 216);
            lblAccountIDInfo.Name = "lblAccountIDInfo";
            lblAccountIDInfo.Size = new Size(350, 25);
            lblAccountIDInfo.TabIndex = 26;
            lblAccountIDInfo.Text = "Account ID found in View Customer Info";
            // 
            // lblLocationIDInfo
            // 
            lblLocationIDInfo.AutoSize = true;
            lblLocationIDInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblLocationIDInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblLocationIDInfo.Location = new Point(112, 408);
            lblLocationIDInfo.Name = "lblLocationIDInfo";
            lblLocationIDInfo.Size = new Size(249, 25);
            lblLocationIDInfo.TabIndex = 27;
            lblLocationIDInfo.Text = "Bentonvl: 1, Rogrs: 2, Fayvl: 3";
            // 
            // Deposit
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(984, 561);
            Controls.Add(lblLocationIDInfo);
            Controls.Add(lblAccountIDInfo);
            Controls.Add(lblDepositAmountInfo);
            Controls.Add(txtLocationID);
            Controls.Add(txtDepositAmount);
            Controls.Add(txtAccountID);
            Controls.Add(btnSubmit);
            Controls.Add(lblLocationID);
            Controls.Add(lblDepositAmount);
            Controls.Add(lblAccountID);
            Controls.Add(pnlFnctScrn);
            MaximizeBox = false;
            Name = "Deposit";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Deposit";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnlFnctScrn.ResumeLayout(false);
            pnlFnctScrn.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblHogBank;
        private PictureBox pictureBox1;
        private Panel pnlFnctScrn;
        private Label lblAccountID;
        private Label lblDepositAmount;
        private Label lblLocationID;
        private Button btnSubmit;
        private TextBox txtAccountID;
        private TextBox txtDepositAmount;
        private TextBox txtLocationID;
        private Label lblDepositAmountInfo;
        private Label lblAccountIDInfo;
        private Label lblLocationIDInfo;
        private Button btnBack;
    }
}