﻿namespace Group_Project_Front_End
{
    partial class AccountInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pnlFnctScrn = new Panel();
            btnBack = new Button();
            lblHogBank = new Label();
            pictureBox1 = new PictureBox();
            lblAccountData = new Label();
            lblTransaction = new Label();
            lblSQLAccountType = new Label();
            lblAccountName = new Label();
            dgvAccountDetails = new DataGridView();
            dgvTransactionHistory = new DataGridView();
            pnlFnctScrn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvAccountDetails).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvTransactionHistory).BeginInit();
            SuspendLayout();
            // 
            // pnlFnctScrn
            // 
            pnlFnctScrn.BackColor = Color.FromArgb(64, 64, 64);
            pnlFnctScrn.Controls.Add(btnBack);
            pnlFnctScrn.Controls.Add(lblHogBank);
            pnlFnctScrn.Controls.Add(pictureBox1);
            pnlFnctScrn.Dock = DockStyle.Top;
            pnlFnctScrn.Location = new Point(0, 0);
            pnlFnctScrn.Margin = new Padding(7, 8, 7, 8);
            pnlFnctScrn.Name = "pnlFnctScrn";
            pnlFnctScrn.Size = new Size(3468, 306);
            pnlFnctScrn.TabIndex = 7;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.Transparent;
            btnBack.BackgroundImage = Properties.Resources.BackArrow;
            btnBack.BackgroundImageLayout = ImageLayout.Zoom;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.ForeColor = Color.Transparent;
            btnBack.Location = new Point(3225, 22);
            btnBack.Margin = new Padding(7, 8, 7, 8);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(233, 262);
            btnBack.TabIndex = 107;
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // lblHogBank
            // 
            lblHogBank.AutoSize = true;
            lblHogBank.Font = new Font("Segoe UI", 39F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHogBank.ForeColor = Color.Transparent;
            lblHogBank.Location = new Point(583, 44);
            lblHogBank.Margin = new Padding(7, 0, 7, 0);
            lblHogBank.Name = "lblHogBank";
            lblHogBank.Size = new Size(1850, 173);
            lblHogBank.TabIndex = 1;
            lblHogBank.Text = "HOG BANK - ACCOUNT INFO";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.RazorBack1;
            pictureBox1.Location = new Point(19, 22);
            pictureBox1.Margin = new Padding(7, 8, 7, 8);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(525, 262);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // lblAccountData
            // 
            lblAccountData.AutoSize = true;
            lblAccountData.FlatStyle = FlatStyle.Flat;
            lblAccountData.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAccountData.Location = new Point(155, 547);
            lblAccountData.Margin = new Padding(7, 0, 7, 0);
            lblAccountData.Name = "lblAccountData";
            lblAccountData.Size = new Size(606, 116);
            lblAccountData.TabIndex = 28;
            lblAccountData.Text = "Account Info:";
            // 
            // lblTransaction
            // 
            lblTransaction.AutoSize = true;
            lblTransaction.FlatStyle = FlatStyle.Flat;
            lblTransaction.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTransaction.Location = new Point(1263, 547);
            lblTransaction.Margin = new Padding(7, 0, 7, 0);
            lblTransaction.Name = "lblTransaction";
            lblTransaction.Size = new Size(876, 116);
            lblTransaction.TabIndex = 30;
            lblTransaction.Text = "Transaction History:";
            // 
            // lblSQLAccountType
            // 
            lblSQLAccountType.AutoSize = true;
            lblSQLAccountType.FlatStyle = FlatStyle.Flat;
            lblSQLAccountType.Font = new Font("Segoe UI", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSQLAccountType.ForeColor = Color.FromArgb(192, 0, 0);
            lblSQLAccountType.Location = new Point(808, 392);
            lblSQLAccountType.Margin = new Padding(7, 0, 7, 0);
            lblSQLAccountType.Name = "lblSQLAccountType";
            lblSQLAccountType.Size = new Size(833, 116);
            lblSQLAccountType.TabIndex = 33;
            lblSQLAccountType.Text = "Account Type Here";
            // 
            // lblAccountName
            // 
            lblAccountName.AutoSize = true;
            lblAccountName.FlatStyle = FlatStyle.Flat;
            lblAccountName.Font = new Font("Segoe UI", 26.25F);
            lblAccountName.Location = new Point(97, 394);
            lblAccountName.Margin = new Padding(7, 0, 7, 0);
            lblAccountName.Name = "lblAccountName";
            lblAccountName.Size = new Size(718, 116);
            lblAccountName.TabIndex = 32;
            lblAccountName.Text = "Viewing Data for:";
            // 
            // dgvAccountDetails
            // 
            dgvAccountDetails.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAccountDetails.Location = new Point(194, 722);
            dgvAccountDetails.Margin = new Padding(7, 8, 7, 8);
            dgvAccountDetails.Name = "dgvAccountDetails";
            dgvAccountDetails.RowHeadersWidth = 102;
            dgvAccountDetails.Size = new Size(933, 1246);
            dgvAccountDetails.TabIndex = 34;
            // 
            // dgvTransactionHistory
            // 
            dgvTransactionHistory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvTransactionHistory.Location = new Point(1302, 722);
            dgvTransactionHistory.Margin = new Padding(7, 8, 7, 8);
            dgvTransactionHistory.Name = "dgvTransactionHistory";
            dgvTransactionHistory.RowHeadersWidth = 102;
            dgvTransactionHistory.Size = new Size(2021, 1246);
            dgvTransactionHistory.TabIndex = 35;
            // 
            // AccountInfo
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(3468, 2048);
            Controls.Add(dgvTransactionHistory);
            Controls.Add(dgvAccountDetails);
            Controls.Add(lblSQLAccountType);
            Controls.Add(lblAccountName);
            Controls.Add(lblTransaction);
            Controls.Add(lblAccountData);
            Controls.Add(pnlFnctScrn);
            Margin = new Padding(7, 8, 7, 8);
            MaximizeBox = false;
            Name = "AccountInfo";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "AccountInfo";
            Load += AccountInfo_Load;
            pnlFnctScrn.ResumeLayout(false);
            pnlFnctScrn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvAccountDetails).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvTransactionHistory).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pnlFnctScrn;
        private Label lblHogBank;
        private PictureBox pictureBox1;
        private Label lblAccountData;
        private Label lblTransaction;
        private Label lblSQLAccountType;
        private Label lblAccountName;
        private DataGridView dgvAccountDetails;
        private DataGridView dgvTransactionHistory;
        private Button btnBack;
    }
}