﻿namespace Group_Project_Front_End
{
    partial class Withdrawal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblHogBank = new Label();
            pictureBox1 = new PictureBox();
            pnlFnctScrn = new Panel();
            btnBack = new Button();
            txtLocationID = new TextBox();
            txtWithdrawalAmount = new TextBox();
            txtAccountID = new TextBox();
            btnSubmit = new Button();
            lblLocationID = new Label();
            lblWithdrawalAmount = new Label();
            lblAccountID = new Label();
            lblAccountIDInfo = new Label();
            lblWithdrawalAmountInfo = new Label();
            lblLocationIDInfo = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnlFnctScrn.SuspendLayout();
            SuspendLayout();
            // 
            // lblHogBank
            // 
            lblHogBank.AutoSize = true;
            lblHogBank.Font = new Font("Segoe UI", 39F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHogBank.ForeColor = Color.Transparent;
            lblHogBank.Location = new Point(583, 44);
            lblHogBank.Margin = new Padding(7, 0, 7, 0);
            lblHogBank.Name = "lblHogBank";
            lblHogBank.Size = new Size(1507, 173);
            lblHogBank.TabIndex = 1;
            lblHogBank.Text = "HOG BANK - WTHDRW";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.RazorBack1;
            pictureBox1.Location = new Point(19, 22);
            pictureBox1.Margin = new Padding(7, 8, 7, 8);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(525, 262);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pnlFnctScrn
            // 
            pnlFnctScrn.BackColor = Color.FromArgb(64, 64, 64);
            pnlFnctScrn.Controls.Add(btnBack);
            pnlFnctScrn.Controls.Add(lblHogBank);
            pnlFnctScrn.Controls.Add(pictureBox1);
            pnlFnctScrn.Dock = DockStyle.Top;
            pnlFnctScrn.Location = new Point(0, 0);
            pnlFnctScrn.Margin = new Padding(7, 8, 7, 8);
            pnlFnctScrn.Name = "pnlFnctScrn";
            pnlFnctScrn.Size = new Size(2390, 306);
            pnlFnctScrn.TabIndex = 6;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.Transparent;
            btnBack.BackgroundImage = Properties.Resources.BackArrow;
            btnBack.BackgroundImageLayout = ImageLayout.Zoom;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.ForeColor = Color.Transparent;
            btnBack.Location = new Point(2137, 22);
            btnBack.Margin = new Padding(7, 8, 7, 8);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(233, 262);
            btnBack.TabIndex = 102;
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // txtLocationID
            // 
            txtLocationID.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtLocationID.Location = new Point(719, 962);
            txtLocationID.Margin = new Padding(7, 8, 7, 8);
            txtLocationID.Name = "txtLocationID";
            txtLocationID.Size = new Size(723, 114);
            txtLocationID.TabIndex = 20;
            txtLocationID.KeyDown += txtLocationID_KeyDown;
            // 
            // txtWithdrawalAmount
            // 
            txtWithdrawalAmount.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtWithdrawalAmount.Location = new Point(1049, 700);
            txtWithdrawalAmount.Margin = new Padding(7, 8, 7, 8);
            txtWithdrawalAmount.Name = "txtWithdrawalAmount";
            txtWithdrawalAmount.Size = new Size(723, 114);
            txtWithdrawalAmount.TabIndex = 19;
            txtWithdrawalAmount.KeyDown += txtWithdrawalAmount_KeyDown;
            // 
            // txtAccountID
            // 
            txtAccountID.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtAccountID.Location = new Point(680, 437);
            txtAccountID.Margin = new Padding(7, 8, 7, 8);
            txtAccountID.Name = "txtAccountID";
            txtAccountID.Size = new Size(723, 114);
            txtAccountID.TabIndex = 18;
            txtAccountID.KeyDown += txtAccountID_KeyDown;
            // 
            // btnSubmit
            // 
            btnSubmit.BackColor = Color.FromArgb(177, 29, 41);
            btnSubmit.FlatAppearance.BorderColor = Color.FromArgb(64, 64, 64);
            btnSubmit.FlatAppearance.BorderSize = 3;
            btnSubmit.FlatStyle = FlatStyle.Flat;
            btnSubmit.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSubmit.ForeColor = Color.White;
            btnSubmit.Location = new Point(214, 1268);
            btnSubmit.Margin = new Padding(7, 8, 7, 8);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(408, 175);
            btnSubmit.TabIndex = 17;
            btnSubmit.Text = "SUBMIT";
            btnSubmit.UseVisualStyleBackColor = false;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // lblLocationID
            // 
            lblLocationID.AutoSize = true;
            lblLocationID.Font = new Font("Segoe UI", 26.25F);
            lblLocationID.Location = new Point(214, 962);
            lblLocationID.Margin = new Padding(7, 0, 7, 0);
            lblLocationID.Name = "lblLocationID";
            lblLocationID.Size = new Size(509, 116);
            lblLocationID.TabIndex = 16;
            lblLocationID.Text = "Location ID:";
            // 
            // lblWithdrawalAmount
            // 
            lblWithdrawalAmount.AutoSize = true;
            lblWithdrawalAmount.Font = new Font("Segoe UI", 26.25F);
            lblWithdrawalAmount.Location = new Point(214, 700);
            lblWithdrawalAmount.Margin = new Padding(7, 0, 7, 0);
            lblWithdrawalAmount.Name = "lblWithdrawalAmount";
            lblWithdrawalAmount.Size = new Size(848, 116);
            lblWithdrawalAmount.TabIndex = 15;
            lblWithdrawalAmount.Text = "Withdrawal Amount:";
            // 
            // lblAccountID
            // 
            lblAccountID.AutoSize = true;
            lblAccountID.Font = new Font("Segoe UI", 26.25F);
            lblAccountID.Location = new Point(214, 437);
            lblAccountID.Margin = new Padding(7, 0, 7, 0);
            lblAccountID.Name = "lblAccountID";
            lblAccountID.Size = new Size(498, 116);
            lblAccountID.TabIndex = 14;
            lblAccountID.Text = "Account ID:";
            // 
            // lblAccountIDInfo
            // 
            lblAccountIDInfo.AutoSize = true;
            lblAccountIDInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAccountIDInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblAccountIDInfo.Location = new Point(272, 590);
            lblAccountIDInfo.Margin = new Padding(7, 0, 7, 0);
            lblAccountIDInfo.Name = "lblAccountIDInfo";
            lblAccountIDInfo.Size = new Size(879, 65);
            lblAccountIDInfo.TabIndex = 21;
            lblAccountIDInfo.Text = "Account ID found in View Customer Info";
            // 
            // lblWithdrawalAmountInfo
            // 
            lblWithdrawalAmountInfo.AutoSize = true;
            lblWithdrawalAmountInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblWithdrawalAmountInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblWithdrawalAmountInfo.Location = new Point(272, 853);
            lblWithdrawalAmountInfo.Margin = new Padding(7, 0, 7, 0);
            lblWithdrawalAmountInfo.Name = "lblWithdrawalAmountInfo";
            lblWithdrawalAmountInfo.Size = new Size(767, 65);
            lblWithdrawalAmountInfo.TabIndex = 22;
            lblWithdrawalAmountInfo.Text = "Non-Negative amount to withdraw";
            // 
            // lblLocationIDInfo
            // 
            lblLocationIDInfo.AutoSize = true;
            lblLocationIDInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblLocationIDInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblLocationIDInfo.Location = new Point(272, 1115);
            lblLocationIDInfo.Margin = new Padding(7, 0, 7, 0);
            lblLocationIDInfo.Name = "lblLocationIDInfo";
            lblLocationIDInfo.Size = new Size(631, 65);
            lblLocationIDInfo.TabIndex = 23;
            lblLocationIDInfo.Text = "Bentonvl: 1, Rogrs: 2, Fayvl: 3";
            // 
            // Withdrawal
            // 
            AutoScaleDimensions = new SizeF(17F, 41F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(2390, 1533);
            Controls.Add(lblLocationIDInfo);
            Controls.Add(lblWithdrawalAmountInfo);
            Controls.Add(lblAccountIDInfo);
            Controls.Add(txtLocationID);
            Controls.Add(txtWithdrawalAmount);
            Controls.Add(txtAccountID);
            Controls.Add(btnSubmit);
            Controls.Add(lblLocationID);
            Controls.Add(lblWithdrawalAmount);
            Controls.Add(lblAccountID);
            Controls.Add(pnlFnctScrn);
            Margin = new Padding(7, 8, 7, 8);
            MaximizeBox = false;
            Name = "Withdrawal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Withdrawal";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnlFnctScrn.ResumeLayout(false);
            pnlFnctScrn.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblHogBank;
        private PictureBox pictureBox1;
        private Panel pnlFnctScrn;
        private TextBox txtLocationID;
        private TextBox txtWithdrawalAmount;
        private TextBox txtAccountID;
        private Button btnSubmit;
        private Label lblLocationID;
        private Label lblWithdrawalAmount;
        private Label lblAccountID;
        private Label lblAccountIDInfo;
        private Label lblWithdrawalAmountInfo;
        private Label lblLocationIDInfo;
        private Button btnBack;
    }
}