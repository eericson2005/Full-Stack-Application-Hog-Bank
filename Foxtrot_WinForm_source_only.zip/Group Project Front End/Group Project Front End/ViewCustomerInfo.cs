﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group_Project_Front_End
{
    public partial class ViewCustomerInfo : Form
    {
        public ViewCustomerInfo()
        {
            InitializeComponent();
        }

        private void ViewCustomerInfo_Load(object sender, EventArgs e)
        {
            // Construct SQL Command for getting customer names
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = @"
                SELECT CustomerID, CustomerFirstName + ' ' + CustomerLastName AS FullName
                FROM Customer
                ORDER BY CustomerFirstName, CustomerLastName
            ";

            // Put the query results into a table
            DataTable dt = new DataTable();
            Walton_DB.FillDataTable_ViaCmd(ref dt, ref cmd);
            dgvCustomers.DataSource = dt; // Fill the dgv with the data in the table

            // -----------------------------------FORMATING START-----------------------------------
            dgvCustomers.RowHeadersVisible = false;
            dgvCustomers.ColumnHeadersVisible = false;
            dgvCustomers.DefaultCellStyle.Font = new Font("Segoe UI", 24);
            dgvCustomers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgvCustomers.Columns["FullName"].Width = 550;
            dgvCustomers.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            dgvCustomers.BackgroundColor = this.BackColor;
            dgvCustomers.BorderStyle = BorderStyle.None;
            dgvCustomers.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvCustomers.DefaultCellStyle.SelectionBackColor = this.BackColor;
            dgvCustomers.DefaultCellStyle.SelectionForeColor = dgvCustomers.DefaultCellStyle.ForeColor;
            dgvCustomers.GridColor = Color.Black;

            // Event to Highlight cell
            dgvCustomers.CellMouseEnter += (s, ev) =>
            {
                if (ev.RowIndex >= 0)
                {
                    dgvCustomers.Rows[ev.RowIndex].DefaultCellStyle.BackColor = Color.FromArgb(177, 29, 41);
                    dgvCustomers.Rows[ev.RowIndex].DefaultCellStyle.ForeColor = Color.White;
                }
            };

            // Event to stop cell Highlight
            dgvCustomers.CellMouseLeave += (s, ev) =>
            {
                if (ev.RowIndex >= 0)
                {
                    dgvCustomers.Rows[ev.RowIndex].DefaultCellStyle.BackColor = dgvCustomers.BackgroundColor;
                    dgvCustomers.Rows[ev.RowIndex].DefaultCellStyle.ForeColor = dgvCustomers.DefaultCellStyle.ForeColor;
                }
            };

            dgvCustomers.AllowUserToAddRows = false;


            // Hide CustomerID column from view but keep it for reference
            dgvCustomers.Columns["CustomerID"].Visible = false;
            // -----------------------------------FORMATING END-----------------------------------
        }

        // Navigate to the next page when cell clicked, saving the customer id with the click and passing it to the next form
        private void dgvCustomers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int customerId = Convert.ToInt32(dgvCustomers.Rows[e.RowIndex].Cells["CustomerID"].Value);
            CustomerAccountInfo nextForm = new CustomerAccountInfo(customerId);
            nextForm.Owner = this; // Set this form to owner for back button
            nextForm.Show();
            this.Hide();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the current form

            if (this.Owner != null)
            {
                this.Owner.Show(); // Show the form that opened this one
            }
            else
            {
                // Bring back to login if no owner established
                Application.OpenForms[0].Show();
            }
        }
    }
}
