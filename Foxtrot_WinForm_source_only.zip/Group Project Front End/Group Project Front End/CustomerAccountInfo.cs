﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group_Project_Front_End
{
    public partial class CustomerAccountInfo : Form
    {
        // Create a variable to hold customer ID from View Customer Info
        int selectedCustomerId;
        public CustomerAccountInfo(int customerId)
        {
            InitializeComponent();
            selectedCustomerId = customerId; // Set the local variable to the customer ID passed in from View Customer Info
        }

        // Load the data in the two dgvs
        private void CustomerAccountInfo_Load(object sender, EventArgs e)
        {
            // Customer Info dgv
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = @"
                SELECT CustomerID, JoinDate, CustomerPhoneNumber, CustomerEmailAddress, CustomerAddress
                FROM Customer
                WHERE CustomerID = @CustomerID
            ";
            cmd.Parameters.Add("@CustomerID", SqlDbType.Int).Value = selectedCustomerId;

            // Fill data table with query results
            DataTable dtCustomer = new DataTable();
            Walton_DB.FillDataTable_ViaCmd(ref dtCustomer, ref cmd);

            // Convert to vertical layout
            DataTable dtCustomerVertical = new DataTable();
            dtCustomerVertical.Columns.Add("Field");
            dtCustomerVertical.Columns.Add("Value");

            if (dtCustomer.Rows.Count > 0)
            {
                DataRow source = dtCustomer.Rows[0];
                dtCustomerVertical.Rows.Add("CustomerID", source["CustomerID"]);
                dtCustomerVertical.Rows.Add("JoinDate", Convert.ToDateTime(source["JoinDate"]).ToString("MM/dd/yyyy"));
                dtCustomerVertical.Rows.Add("CustomerPhoneNumber", source["CustomerPhoneNumber"]);
                dtCustomerVertical.Rows.Add("CustomerEmailAddress", source["CustomerEmailAddress"]);
                dtCustomerVertical.Rows.Add("CustomerAddress", source["CustomerAddress"]);

            }

            dgvCustomerDetails.DataSource = dtCustomerVertical; // Put data into dgv
            dgvCustomerDetails.ClearSelection(); // Prevent autofocusing
            dgvCustomerDetails.CurrentCell = null;

            // -----------------------------------FORMATING START-----------------------------------
            dgvCustomerDetails.RowHeadersVisible = false;
            dgvCustomerDetails.ColumnHeadersVisible = false;
            dgvCustomerDetails.AllowUserToAddRows = false;
            dgvCustomerDetails.DefaultCellStyle.Font = new Font("Segoe UI", 16);
            dgvCustomerDetails.Columns["Field"].DefaultCellStyle.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            dgvCustomerDetails.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            dgvCustomerDetails.GridColor = Color.Black;
            dgvCustomerDetails.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgvCustomerDetails.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvCustomerDetails.BackgroundColor = this.BackColor;
            dgvCustomerDetails.BorderStyle = BorderStyle.None;
            dgvCustomerDetails.ReadOnly = true;
            dgvCustomerDetails.TabStop = false;
            dgvCustomerDetails.Enabled = false;

            if (dgvCustomerDetails.Columns.Contains("CustomerID")) // Re-Show Customer ID in the details
                dgvCustomerDetails.Columns["CustomerID"].Visible = true;
            // -----------------------------------FORMATING END-----------------------------------

            // Retrieve the selected customers full name and update the label at the top of the form
            object fullName = Walton_DB.RetrieveSingleValue($"SELECT CustomerFirstName + ' ' + CustomerLastName FROM Customer WHERE CustomerID = {selectedCustomerId}");
            lblSQLCustomerName.Text = $"{fullName}";

            // Account List dgv
            cmd = new SqlCommand();
            cmd.CommandText = @"
                SELECT AccountID, Description, Balance
                FROM Account
                WHERE CustomerID = @CustomerID
            ";
            cmd.Parameters.Add("@CustomerID", SqlDbType.Int).Value = selectedCustomerId;

            // Fill data table with query results
            DataTable dtAccounts = new DataTable();
            Walton_DB.FillDataTable_ViaCmd(ref dtAccounts, ref cmd);
            dgvAccounts.DataSource = dtAccounts; // Fill the dgv with the data from table

            // -----------------------------------FORMATING START-----------------------------------
            dgvAccounts.RowHeadersVisible = false;
            dgvAccounts.AllowUserToAddRows = false;
            dgvAccounts.ColumnHeadersVisible = true;
            dgvAccounts.DefaultCellStyle.Font = new Font("Segoe UI", 20);
            dgvAccounts.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            dgvAccounts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgvAccounts.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            dgvAccounts.BackgroundColor = this.BackColor;
            dgvAccounts.BorderStyle = BorderStyle.None;
            dgvAccounts.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dgvAccounts.DefaultCellStyle.SelectionBackColor = this.BackColor;
            dgvAccounts.DefaultCellStyle.SelectionForeColor = dgvAccounts.DefaultCellStyle.ForeColor;
            dgvAccounts.GridColor = Color.Black;

            // Highlight cell
            dgvAccounts.CellMouseEnter += (s, ev) =>
            {
                if (ev.RowIndex >= 0)
                {
                    dgvAccounts.Rows[ev.RowIndex].DefaultCellStyle.BackColor = Color.FromArgb(177, 29, 41);
                    dgvAccounts.Rows[ev.RowIndex].DefaultCellStyle.ForeColor = Color.White;
                }
            };

            // Stop Highlight
            dgvAccounts.CellMouseLeave += (s, ev) =>
            {
                if (ev.RowIndex >= 0)
                {
                    dgvAccounts.Rows[ev.RowIndex].DefaultCellStyle.BackColor = dgvAccounts.BackgroundColor;
                    dgvAccounts.Rows[ev.RowIndex].DefaultCellStyle.ForeColor = dgvAccounts.DefaultCellStyle.ForeColor;
                }
            };

            // Hide the AccountID from the dgv but keep for reference
            dgvAccounts.Columns["AccountID"].Visible = false;
            // -----------------------------------FORMATING END-----------------------------------
        }

        // Click event to navigate to next page based on selected account
        private void dgvAccounts_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Extract accountId based on selected account and pass to next form
            int accountId = Convert.ToInt32(dgvAccounts.Rows[e.RowIndex].Cells["AccountID"].Value);
            AccountInfo finalForm = new AccountInfo(accountId);
            finalForm.Owner = this; // This form owner for back button
            finalForm.Show();
            this.Hide();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the current form

            if (this.Owner != null)
            {
                this.Owner.Show(); // Show the form that opened this one
            }
            else
            {
                // Bring back to login if no owner established
                Application.OpenForms[0].Show();
            }
        }
    }
}
