﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Data.SqlClient;

namespace Group_Project_Front_End
{
    public partial class Main_Menu : Form
    {
        // ---------------------PRELOADED TEXT START---------------------
        //Placeholder - Part 1 (Get Windows Send Message function)
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern Int32 SendMessage(IntPtr hWnd, int msg, int wParam, [MarshalAs(UnmanagedType.LPWStr)] string lParam);

        private const int EM_SETCUEBANNER = 0x1501;

        public Main_Menu()
        {
            InitializeComponent();

            //Placeholder - Part 2 (Send placeholder text to controls)
            SendMessage(txtEmail.Handle, EM_SETCUEBANNER, 0, "Email");
            SendMessage(txtPassword.Handle, EM_SETCUEBANNER, 0, "Password");
        }
        // ---------------------PRELOADED TEXT END---------------------

        // ---------------------ENTER PRESS EVENTS START---------------------
        //Enter Press to go to Pass
        private void txtEmployeeID_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtPassword.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true; // Prevent the default ding sound
            }
        }

        //Enter Press to complete login
        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                //Call login button method
                btnLogin_Click(sender, e);
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }
        // ---------------------ENTER PRESS EVENTS END---------------------

        // Login Button method
        private void btnLogin_Click(object sender, EventArgs e)
        {
            // Check that everything is filled out & password and integer
            int parsedPassword = 0;
            if (!string.IsNullOrWhiteSpace(txtEmail.Text) &&
                !string.IsNullOrWhiteSpace(txtPassword.Text) &&
                int.TryParse(txtPassword.Text, out parsedPassword))
            {
                // Create SQL Command & Parameters to prevent SQL Injection
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = @"
                    SELECT EmployeeID, EmployeeFirstName + ' ' + EmployeeLastName AS FullName, Position
                    FROM Employee
                    WHERE EmployeeEmailAddress = @Email AND Password = @Password;
                ";

                cmd.Parameters.Add("@Email", SqlDbType.VarChar, 50).Value = txtEmail.Text;
                cmd.Parameters.Add("@Password", SqlDbType.Int).Value = parsedPassword;

                // Create DataTable to store query results
                DataTable dt = null;
                if (Walton_DB.FillDataTable_ViaCmd(ref dt, ref cmd))
                {
                    // If row count > 0, valid login
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        int employeeID = Convert.ToInt32(dt.Rows[0]["EmployeeID"]);
                        string fullName = dt.Rows[0]["FullName"].ToString();
                        string position = dt.Rows[0]["Position"].ToString();

                        // Save employee ID globally
                        Session.EmployeeID = employeeID;

                        MessageBox.Show("Login Success!\nWelcome, " + position + " " + fullName);

                        // Open next screen and hide login form
                        FunctionScreen fs = new FunctionScreen();
                        fs.Owner = this; // Set the owner of the function screen to this form for back button
                        fs.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Incorrect Email or Password — Login Failed!");
                    }
                }
                else
                {
                    MessageBox.Show("Database or Network Error — Login Failed!");
                }
            }
            else
            {
                MessageBox.Show("Please enter both a valid Email and Password.");
            }
        }

        //Remove Initial Focus
        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            this.ActiveControl = null; // Removes focus from all controls
        }
    }
}
