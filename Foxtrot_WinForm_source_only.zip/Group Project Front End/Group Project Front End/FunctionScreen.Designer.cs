﻿namespace Group_Project_Front_End
{
    partial class FunctionScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnDeposit = new Button();
            btnWithdrawal = new Button();
            btnCreateAcct = new Button();
            btnCreateCustomer = new Button();
            btnViewCustomerInfo = new Button();
            pnlFnctScrn = new Panel();
            btnBack = new Button();
            lblHogBank = new Label();
            pictureBox1 = new PictureBox();
            pnlFnctScrn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnDeposit
            // 
            btnDeposit.BackgroundImage = Properties.Resources.Deposit1;
            btnDeposit.BackgroundImageLayout = ImageLayout.Zoom;
            btnDeposit.FlatAppearance.BorderColor = Color.FromArgb(64, 64, 64);
            btnDeposit.FlatAppearance.BorderSize = 4;
            btnDeposit.FlatStyle = FlatStyle.Flat;
            btnDeposit.Location = new Point(208, 200);
            btnDeposit.Name = "btnDeposit";
            btnDeposit.Size = new Size(230, 230);
            btnDeposit.TabIndex = 0;
            btnDeposit.UseVisualStyleBackColor = true;
            btnDeposit.Click += btnDeposit_Click;
            // 
            // btnWithdrawal
            // 
            btnWithdrawal.BackgroundImage = Properties.Resources.Withdrawal;
            btnWithdrawal.BackgroundImageLayout = ImageLayout.Zoom;
            btnWithdrawal.FlatAppearance.BorderColor = Color.FromArgb(64, 64, 64);
            btnWithdrawal.FlatAppearance.BorderSize = 4;
            btnWithdrawal.FlatStyle = FlatStyle.Flat;
            btnWithdrawal.Location = new Point(600, 200);
            btnWithdrawal.Name = "btnWithdrawal";
            btnWithdrawal.Size = new Size(230, 230);
            btnWithdrawal.TabIndex = 1;
            btnWithdrawal.UseVisualStyleBackColor = true;
            btnWithdrawal.Click += btnWithdrawal_Click;
            // 
            // btnCreateAcct
            // 
            btnCreateAcct.BackgroundImage = Properties.Resources.Create_Account;
            btnCreateAcct.BackgroundImageLayout = ImageLayout.Zoom;
            btnCreateAcct.FlatAppearance.BorderColor = Color.FromArgb(64, 64, 64);
            btnCreateAcct.FlatAppearance.BorderSize = 4;
            btnCreateAcct.FlatStyle = FlatStyle.Flat;
            btnCreateAcct.Location = new Point(992, 200);
            btnCreateAcct.Name = "btnCreateAcct";
            btnCreateAcct.Size = new Size(230, 230);
            btnCreateAcct.TabIndex = 2;
            btnCreateAcct.UseVisualStyleBackColor = true;
            btnCreateAcct.Click += btnCreateAcct_Click;
            // 
            // btnCreateCustomer
            // 
            btnCreateCustomer.BackgroundImage = Properties.Resources.Create_Customer;
            btnCreateCustomer.BackgroundImageLayout = ImageLayout.Zoom;
            btnCreateCustomer.FlatAppearance.BorderColor = Color.FromArgb(64, 64, 64);
            btnCreateCustomer.FlatAppearance.BorderSize = 4;
            btnCreateCustomer.FlatStyle = FlatStyle.Flat;
            btnCreateCustomer.Location = new Point(400, 488);
            btnCreateCustomer.Name = "btnCreateCustomer";
            btnCreateCustomer.Size = new Size(230, 230);
            btnCreateCustomer.TabIndex = 3;
            btnCreateCustomer.UseVisualStyleBackColor = true;
            btnCreateCustomer.Click += btnCreateCustomer_Click;
            // 
            // btnViewCustomerInfo
            // 
            btnViewCustomerInfo.BackgroundImage = Properties.Resources.View_Customer_Info;
            btnViewCustomerInfo.BackgroundImageLayout = ImageLayout.Zoom;
            btnViewCustomerInfo.FlatAppearance.BorderColor = Color.FromArgb(64, 64, 64);
            btnViewCustomerInfo.FlatAppearance.BorderSize = 4;
            btnViewCustomerInfo.FlatStyle = FlatStyle.Flat;
            btnViewCustomerInfo.Location = new Point(800, 488);
            btnViewCustomerInfo.Name = "btnViewCustomerInfo";
            btnViewCustomerInfo.Size = new Size(230, 230);
            btnViewCustomerInfo.TabIndex = 4;
            btnViewCustomerInfo.UseVisualStyleBackColor = true;
            btnViewCustomerInfo.Click += btnViewCustomerInfo_Click;
            // 
            // pnlFnctScrn
            // 
            pnlFnctScrn.BackColor = Color.FromArgb(64, 64, 64);
            pnlFnctScrn.Controls.Add(btnBack);
            pnlFnctScrn.Controls.Add(lblHogBank);
            pnlFnctScrn.Controls.Add(pictureBox1);
            pnlFnctScrn.Dock = DockStyle.Top;
            pnlFnctScrn.Location = new Point(0, 0);
            pnlFnctScrn.Name = "pnlFnctScrn";
            pnlFnctScrn.Size = new Size(1428, 112);
            pnlFnctScrn.TabIndex = 5;
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.Transparent;
            btnBack.BackgroundImage = Properties.Resources.BackArrow;
            btnBack.BackgroundImageLayout = ImageLayout.Zoom;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.ForeColor = Color.Transparent;
            btnBack.Location = new Point(1328, 8);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(96, 96);
            btnBack.TabIndex = 100;
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // lblHogBank
            // 
            lblHogBank.AutoSize = true;
            lblHogBank.Font = new Font("Segoe UI", 39F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHogBank.ForeColor = Color.Transparent;
            lblHogBank.Location = new Point(240, 16);
            lblHogBank.Name = "lblHogBank";
            lblHogBank.Size = new Size(305, 70);
            lblHogBank.TabIndex = 1;
            lblHogBank.Text = "HOG BANK";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.RazorBack1;
            pictureBox1.Location = new Point(8, 8);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(216, 96);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // FunctionScreen
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1428, 782);
            Controls.Add(pnlFnctScrn);
            Controls.Add(btnViewCustomerInfo);
            Controls.Add(btnCreateCustomer);
            Controls.Add(btnCreateAcct);
            Controls.Add(btnWithdrawal);
            Controls.Add(btnDeposit);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "FunctionScreen";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FunctionScreen";
            pnlFnctScrn.ResumeLayout(false);
            pnlFnctScrn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button btnDeposit;
        private Button btnWithdrawal;
        private Button btnCreateAcct;
        private Button btnCreateCustomer;
        private Button btnViewCustomerInfo;
        private Panel pnlFnctScrn;
        private PictureBox pictureBox1;
        private Label lblHogBank;
        private Button btnBack;
    }
}