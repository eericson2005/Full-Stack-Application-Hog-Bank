﻿namespace Group_Project_Front_End
{
    partial class CreateCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblHogBank = new Label();
            pictureBox1 = new PictureBox();
            pnlFnctScrn = new Panel();
            txtFirstName = new TextBox();
            btnSubmit = new Button();
            lblFirstName = new Label();
            txtLastName = new TextBox();
            lblLastName = new Label();
            txtAddress = new TextBox();
            lblAddress = new Label();
            txtPhone = new TextBox();
            lblPhone = new Label();
            txtEmail = new TextBox();
            lblEmail = new Label();
            lblFirstNameInfo = new Label();
            lblLastNameInfo = new Label();
            lblAddressInfo = new Label();
            lblPhoneInfo = new Label();
            lblEmailInfo = new Label();
            btnBack = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnlFnctScrn.SuspendLayout();
            SuspendLayout();
            // 
            // lblHogBank
            // 
            lblHogBank.AutoSize = true;
            lblHogBank.Font = new Font("Segoe UI", 39F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHogBank.ForeColor = Color.Transparent;
            lblHogBank.Location = new Point(240, 16);
            lblHogBank.Name = "lblHogBank";
            lblHogBank.Size = new Size(832, 70);
            lblHogBank.TabIndex = 1;
            lblHogBank.Text = "HOG BANK - CREATE CUSTOMER";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.RazorBack1;
            pictureBox1.Location = new Point(8, 8);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(216, 96);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pnlFnctScrn
            // 
            pnlFnctScrn.BackColor = Color.FromArgb(64, 64, 64);
            pnlFnctScrn.Controls.Add(btnBack);
            pnlFnctScrn.Controls.Add(lblHogBank);
            pnlFnctScrn.Controls.Add(pictureBox1);
            pnlFnctScrn.Dock = DockStyle.Top;
            pnlFnctScrn.Location = new Point(0, 0);
            pnlFnctScrn.Name = "pnlFnctScrn";
            pnlFnctScrn.Size = new Size(1428, 112);
            pnlFnctScrn.TabIndex = 6;
            // 
            // txtFirstName
            // 
            txtFirstName.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtFirstName.Location = new Point(272, 160);
            txtFirstName.Name = "txtFirstName";
            txtFirstName.Size = new Size(500, 50);
            txtFirstName.TabIndex = 21;
            txtFirstName.KeyDown += txtFirstName_KeyDown;
            // 
            // btnSubmit
            // 
            btnSubmit.BackColor = Color.FromArgb(177, 29, 41);
            btnSubmit.FlatAppearance.BorderColor = Color.FromArgb(64, 64, 64);
            btnSubmit.FlatAppearance.BorderSize = 3;
            btnSubmit.FlatStyle = FlatStyle.Flat;
            btnSubmit.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSubmit.ForeColor = Color.White;
            btnSubmit.Location = new Point(88, 664);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(168, 64);
            btnSubmit.TabIndex = 20;
            btnSubmit.Text = "SUBMIT";
            btnSubmit.UseVisualStyleBackColor = false;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // lblFirstName
            // 
            lblFirstName.AutoSize = true;
            lblFirstName.Font = new Font("Segoe UI", 26.25F);
            lblFirstName.Location = new Point(80, 160);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new Size(194, 47);
            lblFirstName.TabIndex = 19;
            lblFirstName.Text = "First Name:";
            // 
            // txtLastName
            // 
            txtLastName.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtLastName.Location = new Point(272, 256);
            txtLastName.Name = "txtLastName";
            txtLastName.Size = new Size(500, 50);
            txtLastName.TabIndex = 23;
            txtLastName.KeyDown += txtLastName_KeyDown;
            // 
            // lblLastName
            // 
            lblLastName.AutoSize = true;
            lblLastName.Font = new Font("Segoe UI", 26.25F);
            lblLastName.Location = new Point(80, 256);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new Size(191, 47);
            lblLastName.TabIndex = 22;
            lblLastName.Text = "Last Name:";
            // 
            // txtAddress
            // 
            txtAddress.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtAddress.Location = new Point(232, 352);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(500, 50);
            txtAddress.TabIndex = 25;
            txtAddress.KeyDown += txtAddress_KeyDown;
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.Font = new Font("Segoe UI", 26.25F);
            lblAddress.Location = new Point(80, 352);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(153, 47);
            lblAddress.TabIndex = 24;
            lblAddress.Text = "Address:";
            // 
            // txtPhone
            // 
            txtPhone.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPhone.Location = new Point(240, 448);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(500, 50);
            txtPhone.TabIndex = 27;
            txtPhone.KeyDown += txtPhone_KeyDown;
            // 
            // lblPhone
            // 
            lblPhone.AutoSize = true;
            lblPhone.Font = new Font("Segoe UI", 26.25F);
            lblPhone.Location = new Point(80, 448);
            lblPhone.Name = "lblPhone";
            lblPhone.Size = new Size(158, 47);
            lblPhone.TabIndex = 26;
            lblPhone.Text = "Phone #:";
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtEmail.Location = new Point(192, 544);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(500, 50);
            txtEmail.TabIndex = 29;
            txtEmail.KeyDown += txtEmail_KeyDown;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Segoe UI", 26.25F);
            lblEmail.Location = new Point(80, 544);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(110, 47);
            lblEmail.TabIndex = 28;
            lblEmail.Text = "Email:";
            // 
            // lblFirstNameInfo
            // 
            lblFirstNameInfo.AutoSize = true;
            lblFirstNameInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblFirstNameInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblFirstNameInfo.Location = new Point(104, 216);
            lblFirstNameInfo.Name = "lblFirstNameInfo";
            lblFirstNameInfo.Size = new Size(188, 25);
            lblFirstNameInfo.TabIndex = 39;
            lblFirstNameInfo.Text = "Customer First Name";
            // 
            // lblLastNameInfo
            // 
            lblLastNameInfo.AutoSize = true;
            lblLastNameInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblLastNameInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblLastNameInfo.Location = new Point(104, 312);
            lblLastNameInfo.Name = "lblLastNameInfo";
            lblLastNameInfo.Size = new Size(186, 25);
            lblLastNameInfo.TabIndex = 40;
            lblLastNameInfo.Text = "Customer Last Name";
            // 
            // lblAddressInfo
            // 
            lblAddressInfo.AutoSize = true;
            lblAddressInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblAddressInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblAddressInfo.Location = new Point(104, 408);
            lblAddressInfo.Name = "lblAddressInfo";
            lblAddressInfo.Size = new Size(285, 25);
            lblAddressInfo.TabIndex = 41;
            lblAddressInfo.Text = "Customer Address (no Zip Code)";
            // 
            // lblPhoneInfo
            // 
            lblPhoneInfo.AutoSize = true;
            lblPhoneInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPhoneInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblPhoneInfo.Location = new Point(104, 504);
            lblPhoneInfo.Name = "lblPhoneInfo";
            lblPhoneInfo.Size = new Size(285, 25);
            lblPhoneInfo.TabIndex = 42;
            lblPhoneInfo.Text = "Customer Phone (no formatting)";
            // 
            // lblEmailInfo
            // 
            lblEmailInfo.AutoSize = true;
            lblEmailInfo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblEmailInfo.ForeColor = Color.FromArgb(177, 29, 41);
            lblEmailInfo.Location = new Point(104, 600);
            lblEmailInfo.Name = "lblEmailInfo";
            lblEmailInfo.Size = new Size(144, 25);
            lblEmailInfo.TabIndex = 43;
            lblEmailInfo.Text = "Customer Email";
            // 
            // btnBack
            // 
            btnBack.BackColor = Color.Transparent;
            btnBack.BackgroundImage = Properties.Resources.BackArrow;
            btnBack.BackgroundImageLayout = ImageLayout.Zoom;
            btnBack.FlatAppearance.BorderSize = 0;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.ForeColor = Color.Transparent;
            btnBack.Location = new Point(1328, 8);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(96, 96);
            btnBack.TabIndex = 104;
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // CreateCustomer
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1428, 782);
            Controls.Add(lblEmailInfo);
            Controls.Add(lblPhoneInfo);
            Controls.Add(lblAddressInfo);
            Controls.Add(lblLastNameInfo);
            Controls.Add(lblFirstNameInfo);
            Controls.Add(txtEmail);
            Controls.Add(lblEmail);
            Controls.Add(txtPhone);
            Controls.Add(lblPhone);
            Controls.Add(txtAddress);
            Controls.Add(lblAddress);
            Controls.Add(txtLastName);
            Controls.Add(lblLastName);
            Controls.Add(txtFirstName);
            Controls.Add(btnSubmit);
            Controls.Add(lblFirstName);
            Controls.Add(pnlFnctScrn);
            MaximizeBox = false;
            Name = "CreateCustomer";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CreateCustomer";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnlFnctScrn.ResumeLayout(false);
            pnlFnctScrn.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblHogBank;
        private PictureBox pictureBox1;
        private Panel pnlFnctScrn;
        private TextBox txtFirstName;
        private Button btnSubmit;
        private Label lblFirstName;
        private TextBox txtLastName;
        private Label lblLastName;
        private TextBox txtAddress;
        private Label lblAddress;
        private TextBox txtPhone;
        private Label lblPhone;
        private TextBox txtEmail;
        private Label lblEmail;
        private Label lblFirstNameInfo;
        private Label lblLastNameInfo;
        private Label lblAddressInfo;
        private Label lblPhoneInfo;
        private Label lblEmailInfo;
        private Button btnBack;
    }
}