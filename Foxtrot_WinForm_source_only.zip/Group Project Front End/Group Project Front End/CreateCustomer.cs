﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group_Project_Front_End
{
    public partial class CreateCustomer : Form
    {
        public CreateCustomer()
        {
            InitializeComponent();
        }

        // ---------------------ENTER PRESS EVENTS START---------------------
        // Enter press to next
        private void txtFirstName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtLastName.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true; // Prevent the default ding sound
            }
        }

        // Enter press to next
        private void txtLastName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtAddress.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }

        // Enter press to next
        private void txtAddress_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtPhone.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }

        // Enter press to next
        private void txtPhone_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtEmail.Focus();
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }

        // Enter press to submit
        private void txtEmail_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                // Click Submit
                btnSubmit_Click(sender, e);
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }
        // ---------------------ENTER PRESS EVENTS END---------------------

        // Submit method
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // Checking that all values filled
            if (!string.IsNullOrWhiteSpace(txtFirstName.Text) &&
                !string.IsNullOrWhiteSpace(txtLastName.Text) &&
                !string.IsNullOrWhiteSpace(txtAddress.Text) &&
                !string.IsNullOrWhiteSpace(txtPhone.Text) &&
                !string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                // SQL commands
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = @"
                    INSERT INTO Customer (
                        CustomerFirstName,
                        CustomerLastName,
                        CustomerAddress,
                        CustomerPhoneNumber,
                        CustomerEmailAddress,
                        JoinDate
                    )
                    VALUES (
                        @FirstName,
                        @LastName,
                        @Address,
                        @PhoneNumber,
                        @Email,
                        @JoinDate
                    );
                ";

                cmd.Parameters.Add("@FirstName", System.Data.SqlDbType.VarChar, 50).Value = txtFirstName.Text;
                cmd.Parameters.Add("@LastName", System.Data.SqlDbType.VarChar, 50).Value = txtLastName.Text;
                cmd.Parameters.Add("@Address", System.Data.SqlDbType.VarChar, 200).Value = txtAddress.Text;
                cmd.Parameters.Add("@PhoneNumber", System.Data.SqlDbType.VarChar, 15).Value = txtPhone.Text;
                cmd.Parameters.Add("@Email", System.Data.SqlDbType.VarChar, 50).Value = txtEmail.Text;
                cmd.Parameters.Add("@JoinDate", System.Data.SqlDbType.Date).Value = DateTime.Now.Date;

                bool success = Walton_DB.ExecSqlCommand(ref cmd);

                if (success)
                {
                    MessageBox.Show("Customer created successfully!");
                    btnBack_Click(sender, e); // Send you back to main function screen
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Failed to create customer.");
                }
            }
            else
            {
                MessageBox.Show("Please enter values for all fields");
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide(); // Hide the current form

            if (this.Owner != null)
            {
                this.Owner.Show(); // Show the form that opened this one
            }
            else
            {
                // Bring back to login if no owner established
                Application.OpenForms[0].Show();
            }
        }
    }
}
